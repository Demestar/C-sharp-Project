﻿namespace Assignment_Combined
{
    partial class ViewWorkers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.datagridviewWorkerList = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnExitViewWorkers = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewWorkerList)).BeginInit();
            this.SuspendLayout();
            // 
            // datagridviewWorkerList
            // 
            this.datagridviewWorkerList.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datagridviewWorkerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewWorkerList.Location = new System.Drawing.Point(98, 116);
            this.datagridviewWorkerList.Name = "datagridviewWorkerList";
            this.datagridviewWorkerList.RowHeadersWidth = 82;
            this.datagridviewWorkerList.RowTemplate.Height = 33;
            this.datagridviewWorkerList.Size = new System.Drawing.Size(1054, 403);
            this.datagridviewWorkerList.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(298, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(601, 58);
            this.label1.TabIndex = 1;
            this.label1.Text = "Here is the list of workers";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExitViewWorkers
            // 
            this.btnExitViewWorkers.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExitViewWorkers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExitViewWorkers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExitViewWorkers.Location = new System.Drawing.Point(522, 552);
            this.btnExitViewWorkers.Name = "btnExitViewWorkers";
            this.btnExitViewWorkers.Size = new System.Drawing.Size(200, 88);
            this.btnExitViewWorkers.TabIndex = 2;
            this.btnExitViewWorkers.Text = "Exit";
            this.btnExitViewWorkers.UseVisualStyleBackColor = false;
            this.btnExitViewWorkers.Click += new System.EventHandler(this.btnExitViewWorkers_Click);
            // 
            // ViewWorkers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.btnExitViewWorkers);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.datagridviewWorkerList);
            this.Name = "ViewWorkers";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewWorkers";
            this.Load += new System.EventHandler(this.Form10_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewWorkerList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView datagridviewWorkerList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnExitViewWorkers;
    }
}