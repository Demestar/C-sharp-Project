﻿namespace Assignment_Combined
{
    partial class ViewWorkersStatic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.datagridviewWorkerList = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewWorkerList)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(312, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(601, 58);
            this.label1.TabIndex = 3;
            this.label1.Text = "Here is the list of workers";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // datagridviewWorkerList
            // 
            this.datagridviewWorkerList.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datagridviewWorkerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewWorkerList.Location = new System.Drawing.Point(137, 140);
            this.datagridviewWorkerList.Name = "datagridviewWorkerList";
            this.datagridviewWorkerList.RowHeadersWidth = 82;
            this.datagridviewWorkerList.RowTemplate.Height = 33;
            this.datagridviewWorkerList.Size = new System.Drawing.Size(973, 493);
            this.datagridviewWorkerList.TabIndex = 2;
            // 
            // ViewWorkersStatic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.datagridviewWorkerList);
            this.Name = "ViewWorkersStatic";
            this.ShowInTaskbar = false;
            this.Text = "ViewWorkersStatic";
            this.Load += new System.EventHandler(this.Form10Static_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewWorkerList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView datagridviewWorkerList;
    }
}