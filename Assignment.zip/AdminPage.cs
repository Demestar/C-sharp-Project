﻿using Assignment_Combined;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class AdminPage : Form
    {
        string username;
        public AdminPage(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private bool isDarkMode = false;
        private void button8_Click(object sender, EventArgs e)
        {
            isDarkMode = !isDarkMode;
            if (isDarkMode)
            {
                // Dark Mode
                this.BackColor = Color.FromArgb(30, 30, 30);
                this.ForeColor = Color.White;
                button8.Text = "Light Mode";
            }
            else
            {
                // Light Mode
                this.BackColor = SystemColors.Control;
                this.ForeColor = SystemColors.ControlText;
                button8.Text = "Dark Mode";
            }
        }

        private void btnAddNewUser_Click(object sender, EventArgs e)
        {
            //Move to Create User Page
            AddUserProfile addUserProfile = new AddUserProfile(username);
            addUserProfile.Show();
            this.Hide();
        }

        private void btnUpdUser_Click(object sender, EventArgs e)
        {
            //Move to Edit User Profile
            EditUserProfile editUserProfile = new EditUserProfile(username);
            editUserProfile.Show();
            this.Hide();
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            //Move to Delete User Page
            DelUserProfile delUserProfile = new DelUserProfile(username);
            delUserProfile.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Back to Login Page
            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void btnGeneReport_Click(object sender, EventArgs e)
        {
            //Go to generate reports page
            ViewReport viewReport = new ViewReport(username);
            viewReport.Show();
            this.Hide();
        }

        private void btnUpdateUserProfile_Click(object sender, EventArgs e)
        {
            //Go to edit user profiles page
            EditUserProfile edituserprofile = new EditUserProfile(username);
            edituserprofile.Show();
            this.Hide();
        }

        private void btnViewUsers_Click(object sender, EventArgs e)
        {
            ViewUsers viewusers = new ViewUsers(username);
            viewusers.Show();
            this.Hide();
        }

        private void AdminPage_Load(object sender, EventArgs e)
        {
            lblWelcomeAdmin.Text = $"Welcome, {username}! What would you like to do?";
        }

    }
}
