﻿namespace Assignment_Combined
{
    partial class ViewServicesStatic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblViewServices = new System.Windows.Forms.Label();
            this.datagridviewViewServices = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewViewServices)).BeginInit();
            this.SuspendLayout();
            // 
            // lblViewServices
            // 
            this.lblViewServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblViewServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewServices.Location = new System.Drawing.Point(188, 62);
            this.lblViewServices.Name = "lblViewServices";
            this.lblViewServices.Size = new System.Drawing.Size(856, 66);
            this.lblViewServices.TabIndex = 4;
            this.lblViewServices.Text = "Here are the prices and discounts of the services";
            this.lblViewServices.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // datagridviewViewServices
            // 
            this.datagridviewViewServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datagridviewViewServices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewViewServices.Location = new System.Drawing.Point(117, 131);
            this.datagridviewViewServices.Name = "datagridviewViewServices";
            this.datagridviewViewServices.RowHeadersWidth = 82;
            this.datagridviewViewServices.RowTemplate.Height = 33;
            this.datagridviewViewServices.Size = new System.Drawing.Size(1009, 484);
            this.datagridviewViewServices.TabIndex = 5;
            // 
            // ViewServicesStatic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.datagridviewViewServices);
            this.Controls.Add(this.lblViewServices);
            this.Name = "ViewServicesStatic";
            this.ShowInTaskbar = false;
            this.Text = "ViewServicesStatic";
            this.Load += new System.EventHandler(this.ViewServicesStatic_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewViewServices)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblViewServices;
        private System.Windows.Forms.DataGridView datagridviewViewServices;
    }
}