﻿namespace Manager
{
    partial class ViewCustomerRequests
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.requestsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.datagridviewRequestStatuses = new System.Windows.Forms.DataGridView();
            this.btnExitRequestStatuses = new System.Windows.Forms.Button();
            this.checkboxShowCompletedRequests = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.requestsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewRequestStatuses)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(303, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(611, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Here is the list of customer requests";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // datagridviewRequestStatuses
            // 
            this.datagridviewRequestStatuses.AllowUserToAddRows = false;
            this.datagridviewRequestStatuses.AllowUserToDeleteRows = false;
            this.datagridviewRequestStatuses.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datagridviewRequestStatuses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewRequestStatuses.Location = new System.Drawing.Point(141, 123);
            this.datagridviewRequestStatuses.Name = "datagridviewRequestStatuses";
            this.datagridviewRequestStatuses.ReadOnly = true;
            this.datagridviewRequestStatuses.RowHeadersWidth = 82;
            this.datagridviewRequestStatuses.RowTemplate.Height = 33;
            this.datagridviewRequestStatuses.Size = new System.Drawing.Size(961, 412);
            this.datagridviewRequestStatuses.TabIndex = 1;
            // 
            // btnExitRequestStatuses
            // 
            this.btnExitRequestStatuses.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExitRequestStatuses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExitRequestStatuses.Location = new System.Drawing.Point(777, 569);
            this.btnExitRequestStatuses.Name = "btnExitRequestStatuses";
            this.btnExitRequestStatuses.Size = new System.Drawing.Size(182, 98);
            this.btnExitRequestStatuses.TabIndex = 2;
            this.btnExitRequestStatuses.Text = "Exit";
            this.btnExitRequestStatuses.UseVisualStyleBackColor = false;
            this.btnExitRequestStatuses.Click += new System.EventHandler(this.btnExitRequestStatuses_Click);
            // 
            // checkboxShowCompletedRequests
            // 
            this.checkboxShowCompletedRequests.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkboxShowCompletedRequests.AutoSize = true;
            this.checkboxShowCompletedRequests.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.checkboxShowCompletedRequests.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkboxShowCompletedRequests.Location = new System.Drawing.Point(207, 579);
            this.checkboxShowCompletedRequests.Name = "checkboxShowCompletedRequests";
            this.checkboxShowCompletedRequests.Size = new System.Drawing.Size(416, 41);
            this.checkboxShowCompletedRequests.TabIndex = 7;
            this.checkboxShowCompletedRequests.Text = "Show completed requests";
            this.checkboxShowCompletedRequests.UseVisualStyleBackColor = false;
            this.checkboxShowCompletedRequests.CheckedChanged += new System.EventHandler(this.checkboxShowCompletedRequests_CheckedChanged);
            // 
            // ViewCustomerRequests
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.checkboxShowCompletedRequests);
            this.Controls.Add(this.btnExitRequestStatuses);
            this.Controls.Add(this.datagridviewRequestStatuses);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "ViewCustomerRequests";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewCustomerRequests";
            this.Load += new System.EventHandler(this.Form8_Load);
            ((System.ComponentModel.ISupportInitialize)(this.requestsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewRequestStatuses)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.BindingSource iOOPASSIGNMENTDataSetBindingSource;
        private System.Windows.Forms.BindingSource requestsBindingSource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView datagridviewRequestStatuses;
        private System.Windows.Forms.Button btnExitRequestStatuses;
        private System.Windows.Forms.CheckBox checkboxShowCompletedRequests;
    }
}