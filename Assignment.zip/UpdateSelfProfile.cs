﻿using Assignment___Customer;
using Manager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Worker;

namespace Assignment
{
    public partial class UpdateSelfProfile : Form
    {
        string username;
        string role;

        int UserID;
        string UsernametoEdit;
        string FullnametoEdit;
        string PasswordtoEdit;
        string GendertoEdit;
        string PhonetoEdit;
        public UpdateSelfProfile(string Username, string Role)
        {
            InitializeComponent();
            username = Username;
            role = Role;
        }

        //This method validates the password
        public static bool ValidatePassword(string password)
        {
            // Check if the password length is at least 8 characters
            if (password.Length < 8)
            {
                MessageBox.Show("Password must be at least 8 characters long.");
                return false;
            }

            // Check if the password contains both letters and numbers
            bool hasLetters = Regex.IsMatch(password, "[a-zA-Z]");
            bool hasNumbers = Regex.IsMatch(password, "[0-9]");

            if (!hasLetters || !hasNumbers)
            {
                MessageBox.Show("Password must contain both letters and numbers.");
                return false;
            }

            // All criteria met
            return true;
        }

        //This method validates whether the username already exists in the database or not
        public bool ValidateUsername(int UserID, string Username)
        {
            string UsernametoCheck = null;
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = $"SELECT Username FROM Users WHERE Username = '{Username}' AND UserID != {UserID}";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectCommand, connection))
                    try
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                            while (reader.Read())
                            {
                                UsernametoCheck = reader.GetString(0);
                            }
                        if (!string.IsNullOrEmpty(UsernametoCheck))
                        {
                            connection.Close();
                            return true;
                        }
                        else
                        {
                            connection.Close();
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        connection.Close();
                        return false;
                    }
            }
        }

        private void CloseFormProcess()
        {
            if (role == "Admin")
            {
                AdminPage adminpage = new AdminPage(username);
                this.Hide();
                adminpage.Show();
            }
            else if (role == "Manager")
            {
                ManagerPage managerpage = new ManagerPage(username);
                this.Hide();
                managerpage.Show();
            }
            else if (role == "Worker")
            {
                WorkerPage workerpage = new WorkerPage(username);
                this.Hide();
                workerpage.Show();
            }
            else
            {
                CustomerMenu customerpage = new CustomerMenu(username);
                this.Hide();
                customerpage.Show();
            }
        }

        private void btnUpdateSelfProfile_Click(object sender, EventArgs e)
        {
            bool shouldUpdate = true;

            //Empty field Validation
            if (String.IsNullOrEmpty(txtUsername.Text) || String.IsNullOrEmpty(txtFullname.Text) || String.IsNullOrEmpty(txtPassword.Text) || String.IsNullOrEmpty(txtPhone.Text))
            {
                MessageBox.Show("Some of the fields are empty/invalid!");
                shouldUpdate = false;
            }
            else if ((rbMale.Checked == true && rbFemale.Checked == true) || (rbMale.Checked == false && rbFemale.Checked == false))
            {
                MessageBox.Show("Some of the fields are empty/invalid!");
                shouldUpdate = false;
            }
            else if (ValidateUsername(UserID, txtUsername.Text) == true)
            {
                MessageBox.Show("That username is already taken!");
                shouldUpdate = false;
            }

            //Password validation
            if (shouldUpdate == true)
            {
                if (ValidatePassword(txtPassword.Text) == false)
                {
                    shouldUpdate = false;
                }
            }

            //Update if everything passes
            if (shouldUpdate == true)
            {
                try
                {
                    int ConvertPhonetoInt = int.Parse(txtPhone.Text);
                    MessageBox.Show("Profile updated successfully!");

                    UsernametoEdit = txtUsername.Text;
                    username = UsernametoEdit;
                    FullnametoEdit = txtFullname.Text;
                    PasswordtoEdit = txtPassword.Text;
                    PhonetoEdit = txtPhone.Text;
                    if (rbMale.Checked == true)
                    {
                        GendertoEdit = "Male";
                    }
                    else
                    {
                        GendertoEdit = "Female";
                    }

                    //Code for updating the profile in the database
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"UPDATE Users SET FullName = '{FullnametoEdit}', Username = '{UsernametoEdit}', Password = '{PasswordtoEdit}', Phone = {ConvertPhonetoInt}, Gender = '{GendertoEdit}' WHERE UserID = {UserID}";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(selectCommand, connection);

                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        connection.Close();

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Some of the fields are empty/invalid!");

                }
            }
        }

        private void btnExitUpdateSelfProfile_Click(object sender, EventArgs e)
        {
            CloseFormProcess();
        }

        private void UpdateSelfProfile_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = $"SELECT * FROM Users WHERE Username = '{username}'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectCommand, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                    while (reader.Read())
                    {
                        // Access data from each column
                        UserID = reader.GetInt32(0);
                        FullnametoEdit = reader.GetString(1);
                        UsernametoEdit = reader.GetString(2);
                        PasswordtoEdit = reader.GetString(3);
                        PhonetoEdit = reader.GetString(4);
                        GendertoEdit = reader.GetString(5);
                    }
                connection.Close();
            }

            txtUsername.Text = UsernametoEdit;
            txtFullname.Text = FullnametoEdit;
            txtPassword.Text = PasswordtoEdit;
            txtPhone.Text = PhonetoEdit;
            if (GendertoEdit == "Male")
            {
                rbMale.Checked = true;
                rbFemale.Checked = false;
            }
            else if (GendertoEdit == "Female")
            {
                rbMale.Checked = false;
                rbFemale.Checked = true;
            }
            else
            {
                rbMale.Checked = false;
                rbFemale.Checked = false;
            }
        }
    }
}
