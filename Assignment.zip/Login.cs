﻿using Assignment___Customer;
using Manager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Worker;

namespace Assignment
{
    public partial class Login : Form
    {
        public string LoginUsername {get; set;}
        public Login()
        {
            InitializeComponent();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtLoginUsername.Text;
            string password = txtLoginPassword.Text;

            string connectionString = @"Data Source=LAPTOP-7KRDTJDO; Initial Catalog=IOOP Assignment; Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = "SELECT Role FROM [Users] WHERE [Username] = @Username AND [Password] = @Password";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);

                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        string role = result.ToString();

                        if (role == "Admin")
                        {
                            //Opens admin page
                            AdminPage adminpage = new AdminPage(username);
                            adminpage.Show();
                            this.Hide();
                        }
                        else if (role == "Manager")
                        {
                            //Opens manager page
                            ManagerPage managerpage = new ManagerPage(username);
                            managerpage.Show();
                            this.Hide();
                        }
                        else if (role == "Worker")
                        {
                            //Opens worker page
                            WorkerPage workerpage = new WorkerPage(username);
                            workerpage.Show();
                            this.Hide();
                        }
                        else
                        {
                            //Opens customer page
                            CustomerMenu customerpage = new CustomerMenu(username);
                            customerpage.Show();
                            this.Hide();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password provided!");
                    }
                }
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            txtLoginPassword.UseSystemPasswordChar = true;
            picboxShowPW.Visible = true;
            picboxHidePW.Visible = false;
        }

        private void picboxShowPW_Click(object sender, EventArgs e)
        {
            txtLoginPassword.UseSystemPasswordChar = false;
            picboxShowPW.Visible = false;
            picboxHidePW.Visible = true;
        }

        private void picboxHidePW_Click(object sender, EventArgs e)
        {
            txtLoginPassword.UseSystemPasswordChar = true;
            picboxShowPW.Visible = true;
            picboxHidePW.Visible = false;
        }
    }
}