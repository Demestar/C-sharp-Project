﻿namespace Assignment___Customer
{
    partial class RequestService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRequestService = new System.Windows.Forms.Label();
            this.lblRequestService4 = new System.Windows.Forms.Label();
            this.lblFee = new System.Windows.Forms.Label();
            this.btnExitRequestService = new System.Windows.Forms.Button();
            this.btnSubmitRequest = new System.Windows.Forms.Button();
            this.btnCalculateFee = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cbUrgent = new System.Windows.Forms.CheckBox();
            this.txtboxService1 = new System.Windows.Forms.TextBox();
            this.txtboxService2 = new System.Windows.Forms.TextBox();
            this.txtboxService3 = new System.Windows.Forms.TextBox();
            this.txtboxService4 = new System.Windows.Forms.TextBox();
            this.txtboxService5 = new System.Windows.Forms.TextBox();
            this.txtboxService6 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblRequestService
            // 
            this.lblRequestService.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRequestService.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRequestService.Location = new System.Drawing.Point(236, 67);
            this.lblRequestService.Name = "lblRequestService";
            this.lblRequestService.Size = new System.Drawing.Size(746, 107);
            this.lblRequestService.TabIndex = 0;
            this.lblRequestService.Text = "Select the number of service(s) you would like to request";
            this.lblRequestService.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRequestService4
            // 
            this.lblRequestService4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRequestService4.AutoSize = true;
            this.lblRequestService4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRequestService4.Location = new System.Drawing.Point(499, 502);
            this.lblRequestService4.Name = "lblRequestService4";
            this.lblRequestService4.Size = new System.Drawing.Size(185, 42);
            this.lblRequestService4.TabIndex = 3;
            this.lblRequestService4.Text = "Fee (RM):";
            this.lblRequestService4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFee
            // 
            this.lblFee.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblFee.AutoSize = true;
            this.lblFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFee.Location = new System.Drawing.Point(680, 504);
            this.lblFee.Name = "lblFee";
            this.lblFee.Size = new System.Drawing.Size(39, 42);
            this.lblFee.TabIndex = 4;
            this.lblFee.Text = "0";
            this.lblFee.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExitRequestService
            // 
            this.btnExitRequestService.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExitRequestService.BackColor = System.Drawing.Color.IndianRed;
            this.btnExitRequestService.Location = new System.Drawing.Point(740, 566);
            this.btnExitRequestService.Name = "btnExitRequestService";
            this.btnExitRequestService.Size = new System.Drawing.Size(211, 74);
            this.btnExitRequestService.TabIndex = 7;
            this.btnExitRequestService.Text = "Exit";
            this.btnExitRequestService.UseVisualStyleBackColor = false;
            this.btnExitRequestService.Click += new System.EventHandler(this.btnExitRequestService_Click);
            // 
            // btnSubmitRequest
            // 
            this.btnSubmitRequest.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSubmitRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSubmitRequest.Location = new System.Drawing.Point(506, 566);
            this.btnSubmitRequest.Name = "btnSubmitRequest";
            this.btnSubmitRequest.Size = new System.Drawing.Size(211, 74);
            this.btnSubmitRequest.TabIndex = 8;
            this.btnSubmitRequest.Text = "Submit";
            this.btnSubmitRequest.UseVisualStyleBackColor = false;
            this.btnSubmitRequest.Click += new System.EventHandler(this.btnSubmitRequest_Click);
            // 
            // btnCalculateFee
            // 
            this.btnCalculateFee.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCalculateFee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCalculateFee.Location = new System.Drawing.Point(277, 566);
            this.btnCalculateFee.Name = "btnCalculateFee";
            this.btnCalculateFee.Size = new System.Drawing.Size(211, 74);
            this.btnCalculateFee.TabIndex = 9;
            this.btnCalculateFee.Text = "Calculate Fee";
            this.btnCalculateFee.UseVisualStyleBackColor = false;
            this.btnCalculateFee.Click += new System.EventHandler(this.btnCalculateFee_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(117, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(435, 37);
            this.label1.TabIndex = 11;
            this.label1.Text = "Printing A4 - Black and White";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(117, 275);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(298, 37);
            this.label2.TabIndex = 12;
            this.label2.Text = "Printing A4 - Colour";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(117, 349);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(354, 37);
            this.label3.TabIndex = 13;
            this.label3.Text = "Binding - Comb Binding";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(700, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(322, 37);
            this.label4.TabIndex = 14;
            this.label4.Text = "Binding - Thick Cover";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(701, 276);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(373, 37);
            this.label5.TabIndex = 15;
            this.label5.Text = "Printing - Poster (A0, A1)";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(701, 349);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(375, 37);
            this.label6.TabIndex = 16;
            this.label6.Text = "Printing - Poster (A2, A3)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbUrgent
            // 
            this.cbUrgent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbUrgent.AutoSize = true;
            this.cbUrgent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbUrgent.Location = new System.Drawing.Point(388, 418);
            this.cbUrgent.Name = "cbUrgent";
            this.cbUrgent.Size = new System.Drawing.Size(490, 41);
            this.cbUrgent.TabIndex = 18;
            this.cbUrgent.Text = "Urgent Request (+10% charge)";
            this.cbUrgent.UseVisualStyleBackColor = true;
            this.cbUrgent.CheckedChanged += new System.EventHandler(this.cbUrgent_CheckedChanged);
            // 
            // txtboxService1
            // 
            this.txtboxService1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtboxService1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxService1.Location = new System.Drawing.Point(558, 195);
            this.txtboxService1.Name = "txtboxService1";
            this.txtboxService1.Size = new System.Drawing.Size(44, 44);
            this.txtboxService1.TabIndex = 19;
            this.txtboxService1.TextChanged += new System.EventHandler(this.txtboxService1_TextChanged);
            // 
            // txtboxService2
            // 
            this.txtboxService2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtboxService2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxService2.Location = new System.Drawing.Point(558, 269);
            this.txtboxService2.Name = "txtboxService2";
            this.txtboxService2.Size = new System.Drawing.Size(44, 44);
            this.txtboxService2.TabIndex = 20;
            this.txtboxService2.TextChanged += new System.EventHandler(this.txtboxService2_TextChanged);
            // 
            // txtboxService3
            // 
            this.txtboxService3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtboxService3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxService3.Location = new System.Drawing.Point(558, 342);
            this.txtboxService3.Name = "txtboxService3";
            this.txtboxService3.Size = new System.Drawing.Size(44, 44);
            this.txtboxService3.TabIndex = 21;
            this.txtboxService3.TextChanged += new System.EventHandler(this.txtboxService3_TextChanged);
            // 
            // txtboxService4
            // 
            this.txtboxService4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtboxService4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxService4.Location = new System.Drawing.Point(1081, 188);
            this.txtboxService4.Name = "txtboxService4";
            this.txtboxService4.Size = new System.Drawing.Size(44, 44);
            this.txtboxService4.TabIndex = 22;
            this.txtboxService4.TextChanged += new System.EventHandler(this.txtboxService4_TextChanged);
            // 
            // txtboxService5
            // 
            this.txtboxService5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtboxService5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxService5.Location = new System.Drawing.Point(1081, 269);
            this.txtboxService5.Name = "txtboxService5";
            this.txtboxService5.Size = new System.Drawing.Size(44, 44);
            this.txtboxService5.TabIndex = 23;
            this.txtboxService5.TextChanged += new System.EventHandler(this.txtboxService5_TextChanged);
            // 
            // txtboxService6
            // 
            this.txtboxService6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtboxService6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxService6.Location = new System.Drawing.Point(1081, 345);
            this.txtboxService6.Name = "txtboxService6";
            this.txtboxService6.Size = new System.Drawing.Size(44, 44);
            this.txtboxService6.TabIndex = 24;
            this.txtboxService6.TextChanged += new System.EventHandler(this.txtboxService6_TextChanged);
            // 
            // RequestService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.txtboxService6);
            this.Controls.Add(this.txtboxService5);
            this.Controls.Add(this.txtboxService4);
            this.Controls.Add(this.txtboxService3);
            this.Controls.Add(this.txtboxService2);
            this.Controls.Add(this.txtboxService1);
            this.Controls.Add(this.cbUrgent);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCalculateFee);
            this.Controls.Add(this.btnSubmitRequest);
            this.Controls.Add(this.btnExitRequestService);
            this.Controls.Add(this.lblFee);
            this.Controls.Add(this.lblRequestService4);
            this.Controls.Add(this.lblRequestService);
            this.Name = "RequestService";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RequestService";
            this.Load += new System.EventHandler(this.RequestService_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRequestService;
        private System.Windows.Forms.Label lblRequestService4;
        private System.Windows.Forms.Label lblFee;
        private System.Windows.Forms.Button btnExitRequestService;
        private System.Windows.Forms.Button btnSubmitRequest;
        private System.Windows.Forms.Button btnCalculateFee;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox cbUrgent;
        private System.Windows.Forms.TextBox txtboxService1;
        private System.Windows.Forms.TextBox txtboxService2;
        private System.Windows.Forms.TextBox txtboxService3;
        private System.Windows.Forms.TextBox txtboxService4;
        private System.Windows.Forms.TextBox txtboxService5;
        private System.Windows.Forms.TextBox txtboxService6;
    }
}