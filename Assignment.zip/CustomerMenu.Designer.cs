﻿namespace Assignment___Customer
{
    partial class CustomerMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCustomerWelcomeMsg = new System.Windows.Forms.Label();
            this.btnViewServices = new System.Windows.Forms.Button();
            this.btnRequestService = new System.Windows.Forms.Button();
            this.btnViewRequestedServices = new System.Windows.Forms.Button();
            this.btnUpdateProfileCustomer = new System.Windows.Forms.Button();
            this.btnLogoutCustomer = new System.Windows.Forms.Button();
            this.picboxCustomerMenu = new System.Windows.Forms.PictureBox();
            this.picboxRequestService = new System.Windows.Forms.PictureBox();
            this.picboxViewServices = new System.Windows.Forms.PictureBox();
            this.picboxUpdateProfile = new System.Windows.Forms.PictureBox();
            this.picboxViewRequestedServices = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picboxCustomerMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxRequestService)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxViewServices)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxUpdateProfile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxViewRequestedServices)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCustomerWelcomeMsg
            // 
            this.lblCustomerWelcomeMsg.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCustomerWelcomeMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerWelcomeMsg.Location = new System.Drawing.Point(352, 83);
            this.lblCustomerWelcomeMsg.Name = "lblCustomerWelcomeMsg";
            this.lblCustomerWelcomeMsg.Size = new System.Drawing.Size(538, 108);
            this.lblCustomerWelcomeMsg.TabIndex = 0;
            this.lblCustomerWelcomeMsg.Text = "Welcome, User! What would you like to do?";
            this.lblCustomerWelcomeMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnViewServices
            // 
            this.btnViewServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnViewServices.AutoSize = true;
            this.btnViewServices.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnViewServices.Location = new System.Drawing.Point(206, 240);
            this.btnViewServices.Name = "btnViewServices";
            this.btnViewServices.Size = new System.Drawing.Size(201, 94);
            this.btnViewServices.TabIndex = 1;
            this.btnViewServices.Text = "View Services";
            this.btnViewServices.UseVisualStyleBackColor = false;
            this.btnViewServices.Click += new System.EventHandler(this.btnViewServices_Click);
            // 
            // btnRequestService
            // 
            this.btnRequestService.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRequestService.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRequestService.Location = new System.Drawing.Point(806, 241);
            this.btnRequestService.Name = "btnRequestService";
            this.btnRequestService.Size = new System.Drawing.Size(201, 94);
            this.btnRequestService.TabIndex = 2;
            this.btnRequestService.Text = "Request a Service";
            this.btnRequestService.UseVisualStyleBackColor = false;
            this.btnRequestService.Click += new System.EventHandler(this.btnRequestService_Click);
            // 
            // btnViewRequestedServices
            // 
            this.btnViewRequestedServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnViewRequestedServices.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnViewRequestedServices.Location = new System.Drawing.Point(206, 402);
            this.btnViewRequestedServices.Name = "btnViewRequestedServices";
            this.btnViewRequestedServices.Size = new System.Drawing.Size(201, 94);
            this.btnViewRequestedServices.TabIndex = 3;
            this.btnViewRequestedServices.Text = "View Requested Services";
            this.btnViewRequestedServices.UseVisualStyleBackColor = false;
            this.btnViewRequestedServices.Click += new System.EventHandler(this.btnViewRequestedServices_Click);
            // 
            // btnUpdateProfileCustomer
            // 
            this.btnUpdateProfileCustomer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUpdateProfileCustomer.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUpdateProfileCustomer.Location = new System.Drawing.Point(806, 403);
            this.btnUpdateProfileCustomer.Name = "btnUpdateProfileCustomer";
            this.btnUpdateProfileCustomer.Size = new System.Drawing.Size(201, 94);
            this.btnUpdateProfileCustomer.TabIndex = 4;
            this.btnUpdateProfileCustomer.Text = "Update Profile";
            this.btnUpdateProfileCustomer.UseVisualStyleBackColor = false;
            this.btnUpdateProfileCustomer.Click += new System.EventHandler(this.btnUpdateProfileCustomer_Click);
            // 
            // btnLogoutCustomer
            // 
            this.btnLogoutCustomer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnLogoutCustomer.BackColor = System.Drawing.Color.IndianRed;
            this.btnLogoutCustomer.Location = new System.Drawing.Point(973, 573);
            this.btnLogoutCustomer.Name = "btnLogoutCustomer";
            this.btnLogoutCustomer.Size = new System.Drawing.Size(201, 94);
            this.btnLogoutCustomer.TabIndex = 5;
            this.btnLogoutCustomer.Text = "Log Out";
            this.btnLogoutCustomer.UseVisualStyleBackColor = false;
            this.btnLogoutCustomer.Click += new System.EventHandler(this.btnLogoutCustomer_Click);
            // 
            // picboxCustomerMenu
            // 
            this.picboxCustomerMenu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picboxCustomerMenu.Image = global::Assignment_Combined.Properties.Resources.printer1;
            this.picboxCustomerMenu.Location = new System.Drawing.Point(467, 241);
            this.picboxCustomerMenu.Name = "picboxCustomerMenu";
            this.picboxCustomerMenu.Size = new System.Drawing.Size(288, 259);
            this.picboxCustomerMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxCustomerMenu.TabIndex = 10;
            this.picboxCustomerMenu.TabStop = false;
            // 
            // picboxRequestService
            // 
            this.picboxRequestService.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picboxRequestService.Image = global::Assignment_Combined.Properties.Resources._7338001;
            this.picboxRequestService.Location = new System.Drawing.Point(1019, 240);
            this.picboxRequestService.Name = "picboxRequestService";
            this.picboxRequestService.Size = new System.Drawing.Size(100, 94);
            this.picboxRequestService.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxRequestService.TabIndex = 9;
            this.picboxRequestService.TabStop = false;
            // 
            // picboxViewServices
            // 
            this.picboxViewServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picboxViewServices.Image = global::Assignment_Combined.Properties.Resources.services_icon_01;
            this.picboxViewServices.Location = new System.Drawing.Point(98, 239);
            this.picboxViewServices.Name = "picboxViewServices";
            this.picboxViewServices.Size = new System.Drawing.Size(101, 94);
            this.picboxViewServices.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxViewServices.TabIndex = 8;
            this.picboxViewServices.TabStop = false;
            // 
            // picboxUpdateProfile
            // 
            this.picboxUpdateProfile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picboxUpdateProfile.Image = global::Assignment_Combined.Properties.Resources.profile;
            this.picboxUpdateProfile.Location = new System.Drawing.Point(1022, 407);
            this.picboxUpdateProfile.Name = "picboxUpdateProfile";
            this.picboxUpdateProfile.Size = new System.Drawing.Size(91, 86);
            this.picboxUpdateProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxUpdateProfile.TabIndex = 7;
            this.picboxUpdateProfile.TabStop = false;
            // 
            // picboxViewRequestedServices
            // 
            this.picboxViewRequestedServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picboxViewRequestedServices.Image = global::Assignment_Combined.Properties.Resources._1f50d;
            this.picboxViewRequestedServices.Location = new System.Drawing.Point(110, 407);
            this.picboxViewRequestedServices.Name = "picboxViewRequestedServices";
            this.picboxViewRequestedServices.Size = new System.Drawing.Size(83, 81);
            this.picboxViewRequestedServices.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxViewRequestedServices.TabIndex = 6;
            this.picboxViewRequestedServices.TabStop = false;
            // 
            // CustomerMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.picboxCustomerMenu);
            this.Controls.Add(this.picboxRequestService);
            this.Controls.Add(this.picboxViewServices);
            this.Controls.Add(this.picboxUpdateProfile);
            this.Controls.Add(this.picboxViewRequestedServices);
            this.Controls.Add(this.btnLogoutCustomer);
            this.Controls.Add(this.btnUpdateProfileCustomer);
            this.Controls.Add(this.btnViewRequestedServices);
            this.Controls.Add(this.btnRequestService);
            this.Controls.Add(this.btnViewServices);
            this.Controls.Add(this.lblCustomerWelcomeMsg);
            this.Name = "CustomerMenu";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CustomerMenu";
            this.Load += new System.EventHandler(this.CustomerMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picboxCustomerMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxRequestService)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxViewServices)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxUpdateProfile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxViewRequestedServices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCustomerWelcomeMsg;
        private System.Windows.Forms.Button btnViewServices;
        private System.Windows.Forms.Button btnRequestService;
        private System.Windows.Forms.Button btnViewRequestedServices;
        private System.Windows.Forms.Button btnUpdateProfileCustomer;
        private System.Windows.Forms.Button btnLogoutCustomer;
        private System.Windows.Forms.PictureBox picboxViewRequestedServices;
        private System.Windows.Forms.PictureBox picboxUpdateProfile;
        private System.Windows.Forms.PictureBox picboxViewServices;
        private System.Windows.Forms.PictureBox picboxRequestService;
        private System.Windows.Forms.PictureBox picboxCustomerMenu;
    }
}

