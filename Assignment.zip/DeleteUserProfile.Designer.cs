﻿namespace Assignment
{
    partial class DelUserProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExitDeleteUserProfile = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtUserIDtoDelete = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.datagridviewUserList = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewUserList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExitDeleteUserProfile
            // 
            this.btnExitDeleteUserProfile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExitDeleteUserProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExitDeleteUserProfile.Location = new System.Drawing.Point(667, 189);
            this.btnExitDeleteUserProfile.Margin = new System.Windows.Forms.Padding(4);
            this.btnExitDeleteUserProfile.Name = "btnExitDeleteUserProfile";
            this.btnExitDeleteUserProfile.Size = new System.Drawing.Size(164, 79);
            this.btnExitDeleteUserProfile.TabIndex = 9;
            this.btnExitDeleteUserProfile.Text = "Exit";
            this.btnExitDeleteUserProfile.UseVisualStyleBackColor = false;
            this.btnExitDeleteUserProfile.Click += new System.EventHandler(this.btnExitDeleteUserProfile_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnDelete.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnDelete.Location = new System.Drawing.Point(378, 189);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(164, 79);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtUserIDtoDelete
            // 
            this.txtUserIDtoDelete.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtUserIDtoDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUserIDtoDelete.Location = new System.Drawing.Point(577, 132);
            this.txtUserIDtoDelete.Margin = new System.Windows.Forms.Padding(4);
            this.txtUserIDtoDelete.Name = "txtUserIDtoDelete";
            this.txtUserIDtoDelete.Size = new System.Drawing.Size(59, 49);
            this.txtUserIDtoDelete.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label2.Location = new System.Drawing.Point(323, 52);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(580, 72);
            this.label2.TabIndex = 6;
            this.label2.Text = "Please enter the user ID to delete";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label1.Location = new System.Drawing.Point(395, -3);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(444, 57);
            this.label1.TabIndex = 5;
            this.label1.Text = "Delete User Profile";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // datagridviewUserList
            // 
            this.datagridviewUserList.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datagridviewUserList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewUserList.Location = new System.Drawing.Point(173, 335);
            this.datagridviewUserList.Name = "datagridviewUserList";
            this.datagridviewUserList.RowHeadersWidth = 82;
            this.datagridviewUserList.RowTemplate.Height = 33;
            this.datagridviewUserList.Size = new System.Drawing.Size(890, 349);
            this.datagridviewUserList.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(311, 273);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(583, 59);
            this.label3.TabIndex = 10;
            this.label3.Text = "Here is the list of all users";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DelUserProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.datagridviewUserList);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnExitDeleteUserProfile);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtUserIDtoDelete);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "DelUserProfile";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Delete User Page";
            this.Load += new System.EventHandler(this.DelUserProfile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewUserList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExitDeleteUserProfile;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtUserIDtoDelete;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView datagridviewUserList;
        private System.Windows.Forms.Label label3;
    }
}