﻿using Assignment;
using Assignment_Combined;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Worker
{

    public partial class UpdateRequestStatus : Form
    {
        int UserID;
        string username;

        public UpdateRequestStatus(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            WorkerPage workerpage = new WorkerPage(username);
            workerpage.Show();
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            bool shouldUpdate = true;

            //Validates the inputs
            if (String.IsNullOrEmpty(txtRequestID.Text) || cboStatus.SelectedIndex == -1)
            {
                MessageBox.Show("One or both of the fields are empty!");
                shouldUpdate = false;
            }
            else
            {
                try
                {
                    int.Parse(txtRequestID.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid request id provided!");
                    shouldUpdate = false;
                }
            }

            //Ensures that the request is assigned to this worker
            if (shouldUpdate == true)
            {
                int WorkerIDtoCheck = -1;
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"SELECT WorkerUserID FROM Requests WHERE RequestID = {txtRequestID.Text}";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(selectCommand, connection))
                        try
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                                while (reader.Read())
                                {
                                    WorkerIDtoCheck = reader.GetInt32(0);
                                }
                            if (WorkerIDtoCheck == UserID)
                            {
                                connection.Close();
                            }
                            else
                            {
                                connection.Close();
                                shouldUpdate = false;
                                MessageBox.Show("That request is not under your assignment!");
                            }
                        }
                        catch (Exception ex)
                        {
                            connection.Close();
                            shouldUpdate = false;
                            MessageBox.Show("That request is not under your assignment!");
                        }
                }
            }

            //Updates the status
            if (shouldUpdate == true)
            {
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"UPDATE Requests SET Status = '{cboStatus.Text}' WHERE RequestID = {txtRequestID.Text}";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(selectCommand, connection);

                    connection.Open();
                    int affectedRows = command.ExecuteNonQuery();
                    connection.Close();

                }
                MessageBox.Show("Request status successfully updated!");
            }

            if (shouldUpdate == true)
            {
                //Loads the list of assigned incomplete requests based on the worker's user id
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"SELECT RequestID, ServiceName, NumofRequests, Price, Status, Urgent, DateRequested FROM Requests WHERE WorkerUserID = {UserID} AND Status != 'Completed' ORDER BY DateRequested";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                    DataTable table = new DataTable();
                    table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dataAdapter.Fill(table);
                    datagridviewAssignedRequests.ReadOnly = true;
                    datagridviewAssignedRequests.DataSource = table;
                }
            }
        }

        private void Form13_Load(object sender, EventArgs e)
        {
            //Gets the worker's user id
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = $"SELECT * FROM Users WHERE Username = '{username}'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectCommand, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                    while (reader.Read())
                    {
                        UserID = reader.GetInt32(0);
                    }
                connection.Close();
            }

            //Loads the list of assigned incomplete requests based on the worker's user id
            connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            selectCommand = $"SELECT RequestID, ServiceName, NumofRequests, Price, Status, Urgent, DateRequested FROM Requests WHERE WorkerUserID = {UserID} AND Status != 'Completed' ORDER BY DateRequested";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                DataTable table = new DataTable();
                table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(table);
                datagridviewAssignedRequests.ReadOnly = true;
                datagridviewAssignedRequests.DataSource = table;
            }
        }
    }
}
