﻿namespace Assignment___Customer
{
    partial class ViewRequestedServices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblViewRequestedServices = new System.Windows.Forms.Label();
            this.btnExitViewRequestedServices = new System.Windows.Forms.Button();
            this.datagridviewRequestedServices = new System.Windows.Forms.DataGridView();
            this.checkboxShowCompletedRequests = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtboxRequestID = new System.Windows.Forms.TextBox();
            this.btnCancelRequest = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewRequestedServices)).BeginInit();
            this.SuspendLayout();
            // 
            // lblViewRequestedServices
            // 
            this.lblViewRequestedServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblViewRequestedServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewRequestedServices.Location = new System.Drawing.Point(190, 4);
            this.lblViewRequestedServices.Name = "lblViewRequestedServices";
            this.lblViewRequestedServices.Size = new System.Drawing.Size(823, 76);
            this.lblViewRequestedServices.TabIndex = 0;
            this.lblViewRequestedServices.Text = "Here is the list of your requested services";
            this.lblViewRequestedServices.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExitViewRequestedServices
            // 
            this.btnExitViewRequestedServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExitViewRequestedServices.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExitViewRequestedServices.Location = new System.Drawing.Point(738, 454);
            this.btnExitViewRequestedServices.Name = "btnExitViewRequestedServices";
            this.btnExitViewRequestedServices.Size = new System.Drawing.Size(172, 56);
            this.btnExitViewRequestedServices.TabIndex = 3;
            this.btnExitViewRequestedServices.Text = "Exit";
            this.btnExitViewRequestedServices.UseVisualStyleBackColor = false;
            this.btnExitViewRequestedServices.Click += new System.EventHandler(this.btnExitViewRequestedServices_Click);
            // 
            // datagridviewRequestedServices
            // 
            this.datagridviewRequestedServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datagridviewRequestedServices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewRequestedServices.Location = new System.Drawing.Point(197, 76);
            this.datagridviewRequestedServices.Name = "datagridviewRequestedServices";
            this.datagridviewRequestedServices.RowHeadersWidth = 82;
            this.datagridviewRequestedServices.RowTemplate.Height = 33;
            this.datagridviewRequestedServices.Size = new System.Drawing.Size(842, 360);
            this.datagridviewRequestedServices.TabIndex = 4;
            // 
            // checkboxShowCompletedRequests
            // 
            this.checkboxShowCompletedRequests.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkboxShowCompletedRequests.AutoSize = true;
            this.checkboxShowCompletedRequests.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.checkboxShowCompletedRequests.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkboxShowCompletedRequests.Location = new System.Drawing.Point(278, 461);
            this.checkboxShowCompletedRequests.Name = "checkboxShowCompletedRequests";
            this.checkboxShowCompletedRequests.Size = new System.Drawing.Size(416, 41);
            this.checkboxShowCompletedRequests.TabIndex = 5;
            this.checkboxShowCompletedRequests.Text = "Show completed requests";
            this.checkboxShowCompletedRequests.UseVisualStyleBackColor = false;
            this.checkboxShowCompletedRequests.CheckedChanged += new System.EventHandler(this.checkboxShowCompletedRequests_CheckedChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(219, 548);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(781, 37);
            this.label1.TabIndex = 6;
            this.label1.Text = "You can cancel requests that have the status of \"new\"";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(361, 602);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 33);
            this.label2.TabIndex = 7;
            this.label2.Text = "Request ID:";
            // 
            // txtboxRequestID
            // 
            this.txtboxRequestID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtboxRequestID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxRequestID.Location = new System.Drawing.Point(545, 599);
            this.txtboxRequestID.Name = "txtboxRequestID";
            this.txtboxRequestID.Size = new System.Drawing.Size(57, 40);
            this.txtboxRequestID.TabIndex = 8;
            // 
            // btnCancelRequest
            // 
            this.btnCancelRequest.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCancelRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCancelRequest.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelRequest.Location = new System.Drawing.Point(690, 594);
            this.btnCancelRequest.Name = "btnCancelRequest";
            this.btnCancelRequest.Size = new System.Drawing.Size(152, 56);
            this.btnCancelRequest.TabIndex = 9;
            this.btnCancelRequest.Text = "Cancel";
            this.btnCancelRequest.UseVisualStyleBackColor = false;
            this.btnCancelRequest.Click += new System.EventHandler(this.btnCancelRequest_Click);
            // 
            // ViewRequestedServices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancelRequest);
            this.Controls.Add(this.txtboxRequestID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkboxShowCompletedRequests);
            this.Controls.Add(this.datagridviewRequestedServices);
            this.Controls.Add(this.btnExitViewRequestedServices);
            this.Controls.Add(this.lblViewRequestedServices);
            this.Name = "ViewRequestedServices";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewRequestedServices";
            this.Load += new System.EventHandler(this.ViewRequestedServices_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewRequestedServices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblViewRequestedServices;
        private System.Windows.Forms.Button btnExitViewRequestedServices;
        private System.Windows.Forms.DataGridView datagridviewRequestedServices;
        private System.Windows.Forms.CheckBox checkboxShowCompletedRequests;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtboxRequestID;
        private System.Windows.Forms.Button btnCancelRequest;
    }
}