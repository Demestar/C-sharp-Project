﻿using Assignment_Combined;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Assignment___Customer
{
    public partial class RequestService : Form
    {
        ViewServicesStatic viewservicesstatic = new ViewServicesStatic();
        int UserID;
        string username;

        int NumService1 = 0;
        int NumService2 = 0;
        int NumService3 = 0;
        int NumService4 = 0;
        int NumService5 = 0;
        int NumService6 = 0;
        double totalfee = 0;
        bool urgent = false;

        private Service PrintingA4BlackAndWhite, PrintingA4Color, BindingCombBinding, BindingThickCover, PrintingPosterA0A1, PrintingPosterA2A3;

        private void txtboxService2_TextChanged(object sender, EventArgs e)
        {
            lblFee.Text = "0";
        }

        private void txtboxService3_TextChanged(object sender, EventArgs e)
        {
            lblFee.Text = "0";
        }

        private void txtboxService4_TextChanged(object sender, EventArgs e)
        {
            lblFee.Text = "0";
        }

        private void txtboxService5_TextChanged(object sender, EventArgs e)
        {
            lblFee.Text = "0";
        }

        private void txtboxService6_TextChanged(object sender, EventArgs e)
        {
            lblFee.Text = "0";
        }

        private void cbUrgent_CheckedChanged(object sender, EventArgs e)
        {
            lblFee.Text = "0";
        }

        private void RequestService_Load(object sender, EventArgs e)
        {
            viewservicesstatic.Show();

            //Gets the customer's user id
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = $"SELECT * FROM Users WHERE Username = '{username}'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectCommand, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                    while (reader.Read())
                    {
                        UserID = reader.GetInt32(0);
                    }
                connection.Close();
            }
        }

        private void txtboxService1_TextChanged(object sender, EventArgs e)
        {
            lblFee.Text = "0";
        }

        private void btnSubmitRequest_Click(object sender, EventArgs e)
        {
            string isUrgent = "No";
            DateTime currentDate = DateTime.Now;

            if (lblFee.Text == "0")
            {
                MessageBox.Show("Please calculate the fees first before submitting!");
            }
            else
            {
                MessageBox.Show("Request(s) successfully submitted!");

                //Code for updating the database
                if (cbUrgent.Checked == true)
                {
                    isUrgent = "Yes";
                }
                else
                {
                    isUrgent = "No";
                }

                if (NumService1 > 0)
                {
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"INSERT INTO Requests (ServiceID, ServiceName, NumofRequests, Price, CustomerUserID, WorkerUserID, Status, Urgent, DateRequested) VALUES (1, 'Printing A4 - Black and White', {NumService1}, {PrintingA4BlackAndWhite.CalculatePrice(NumService1)}, {UserID}, NULL, 'New', '{isUrgent}', '{currentDate.ToString("yyyy/MM/dd")}')";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(selectCommand, connection);

                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        connection.Close();
                    }
                }

                if (NumService2 > 0)
                {
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"INSERT INTO Requests (ServiceID, ServiceName, NumofRequests, Price, CustomerUserID, WorkerUserID, Status, Urgent, DateRequested) VALUES (2, 'Printing A4 - Colour', {NumService2}, {PrintingA4Color.CalculatePrice(NumService2)}, {UserID}, NULL, 'New', '{isUrgent}', '{currentDate.ToString("yyyy/MM/dd")}')";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(selectCommand, connection);

                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        connection.Close();
                    }
                }

                if (NumService3 > 0)
                {
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"INSERT INTO Requests (ServiceID, ServiceName, NumofRequests, Price, CustomerUserID, WorkerUserID, Status, Urgent, DateRequested) VALUES (3, 'Binding - Comb Binding', {NumService3}, {BindingCombBinding.CalculatePrice(NumService3)}, {UserID}, NULL, 'New', '{isUrgent}', '{currentDate.ToString("yyyy/MM/dd")}')";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(selectCommand, connection);

                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        connection.Close();
                    }
                }

                if (NumService4 > 0)
                {
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"INSERT INTO Requests (ServiceID, ServiceName, NumofRequests, Price, CustomerUserID, WorkerUserID, Status, Urgent, DateRequested) VALUES (4, 'Binding - Thick Cover', {NumService4}, {BindingThickCover.CalculatePrice(NumService4)}, {UserID}, NULL, 'New', '{isUrgent}', '{currentDate.ToString("yyyy/MM/dd")}')";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(selectCommand, connection);

                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        connection.Close();
                    }
                }

                if (NumService5 > 0)
                {
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"INSERT INTO Requests (ServiceID, ServiceName, NumofRequests, Price, CustomerUserID, WorkerUserID, Status, Urgent, DateRequested) VALUES (5, 'Printing - Poster (A0, A1)', {NumService5}, {PrintingPosterA0A1.CalculatePrice(NumService5)}, {UserID}, NULL, 'New', '{isUrgent}', '{currentDate.ToString("yyyy/MM/dd")}')";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(selectCommand, connection);

                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        connection.Close();
                    }
                }

                if (NumService6 > 0)
                {
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"INSERT INTO Requests (ServiceID, ServiceName, NumofRequests, Price, CustomerUserID, WorkerUserID, Status, Urgent, DateRequested) VALUES (6, 'Printing - Poster (A2, A3)', {NumService6}, {PrintingPosterA2A3.CalculatePrice(NumService6)}, {UserID}, NULL, 'New', '{isUrgent}', '{currentDate.ToString("yyyy/MM/dd")}')";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(selectCommand, connection);

                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        connection.Close();
                    }
                }

                //Code for resetting the variables
                txtboxService1.Text = "";
                txtboxService2.Text = "";
                txtboxService3.Text = "";
                txtboxService4.Text = "";
                txtboxService5.Text = "";
                txtboxService6.Text = "";
                cbUrgent.Checked = false;
                lblFee.Text = "0";

                NumService1 = 0;
                NumService2 = 0;
                NumService3 = 0;
                NumService4 = 0;
                NumService5 = 0;
                NumService6 = 0;
                totalfee = 0;
                urgent = false;
            }
        }

        private void btnCalculateFee_Click(object sender, EventArgs e)
        {
            bool ShouldCalculate = true;

            if (String.IsNullOrEmpty(txtboxService1.Text))
            {
                NumService1 = 0;
            }
            else
            {
                try
                {
                    NumService1 = int.Parse(txtboxService1.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("The value provided for Printing A4 - Black and White is invalid!");
                    ShouldCalculate = false;
                }
            }

            if (String.IsNullOrEmpty(txtboxService2.Text))
            {
                NumService2 = 0;
            }
            else
            {
                try
                {
                    NumService2 = int.Parse(txtboxService2.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("The value provided for Printing A4 - Colour is invalid!");
                    ShouldCalculate = false;
                }
            }

            if (String.IsNullOrEmpty(txtboxService3.Text))
            {
                NumService3 = 0;
            }
            else
            {
                try
                {
                    NumService3 = int.Parse(txtboxService3.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("The value provided for Binding - Comb Binding is invalid!");
                    ShouldCalculate = false;
                }
            }

            if (String.IsNullOrEmpty(txtboxService4.Text))
            {
                NumService4 = 0;
            }
            else
            {
                try
                {
                    NumService4 = int.Parse(txtboxService4.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("The value provided for Binding - Thick Cover is invalid!");
                    ShouldCalculate = false;
                }
            }

            if (String.IsNullOrEmpty(txtboxService5.Text))
            {
                NumService5 = 0;
            }
            else
            {
                try
                {
                    NumService5 = int.Parse(txtboxService5.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("The value provided for Printing - Poster (A0, A1) is invalid!");
                    ShouldCalculate = false;
                }
            }

            if (String.IsNullOrEmpty(txtboxService6.Text))
            {
                NumService6 = 0;
            }
            else
            {
                try
                {
                    NumService6 = int.Parse(txtboxService6.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("The value provided for Printing - Poster (A2, A3) is invalid!");
                    ShouldCalculate = false;
                }
            }

            if (ShouldCalculate == true)
            {
                totalfee = PrintingA4BlackAndWhite.CalculatePrice(NumService1) + PrintingA4Color.CalculatePrice(NumService2) + BindingCombBinding.CalculatePrice(NumService3) + BindingThickCover.CalculatePrice(NumService4) + PrintingPosterA0A1.CalculatePrice(NumService5) + PrintingPosterA2A3.CalculatePrice(NumService6);

                if (cbUrgent.Checked == true)
                {
                    urgent = true;
                    totalfee = totalfee * 1.1;
                }

                lblFee.Text = totalfee.ToString();
            }
        }

        public RequestService(string Username)
        {
            InitializeComponent();
            username = Username;

            PrintingA4BlackAndWhite = new Service(0, 0.8, 10, 100);
            PrintingA4Color = new Service(1, 2.5, 10, 100);
            BindingCombBinding = new Service(2, 5.5);
            BindingThickCover = new Service(3, 9.3);
            PrintingPosterA0A1 = new Service(4, 6, 10, 100);
            PrintingPosterA2A3 = new Service(5, 3, 10, 100);
        }
       
        private void btnExitRequestService_Click(object sender, EventArgs e)
        {
            CustomerMenu cm = new CustomerMenu(username);
            cm.Show();
            viewservicesstatic.Close();
            this.Close();
        }
    }
}
