﻿using Assignment;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment___Customer
{
    public partial class CustomerMenu : Form
    {
        string username;
        public CustomerMenu(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private void btnViewServices_Click(object sender, EventArgs e)
        {
            ViewServices vs = new ViewServices(username);
            vs.Show();
            this.Hide();
        }

        private void btnRequestService_Click(object sender, EventArgs e)
        {
            RequestService rs = new RequestService(username);
            rs.Show();
            this.Hide();
        }

        private void btnViewRequestedServices_Click(object sender, EventArgs e)
        {
            ViewRequestedServices vrs = new ViewRequestedServices(username);
            vrs.Show();
            this.Hide();
        }

        private void btnLogoutCustomer_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void btnUpdateProfileCustomer_Click(object sender, EventArgs e)
        {
            UpdateSelfProfile updateselfprofile = new UpdateSelfProfile(username, "Customer");
            updateselfprofile.Show();
            this.Hide();
        }

        private void CustomerMenu_Load(object sender, EventArgs e)
        {
            lblCustomerWelcomeMsg.Text = $"Welcome, {username}! What would you like to do?";
        }
    }
}
