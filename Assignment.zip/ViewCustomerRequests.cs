﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Manager
{
    public partial class ViewCustomerRequests : Form
    {
        string username;
        public ViewCustomerRequests(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private void btnExitRequestStatuses_Click(object sender, EventArgs e)
        {
            ManagerPage managerpage = new ManagerPage(username);
            managerpage.Show();
            this.Close();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            checkboxShowCompletedRequests.Checked = false;

            //Loads the list of incomplete customer requests
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = "SELECT RequestID, ServiceName, NumofRequests, CustomerUserID, WorkerUserID, Status, Urgent, DateRequested FROM Requests WHERE Status != 'Completed' ORDER BY Urgent DESC";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                DataTable table = new DataTable();
                table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(table);
                datagridviewRequestStatuses.ReadOnly = true;
                datagridviewRequestStatuses.DataSource = table;
            }
        }

        private void checkboxShowCompletedRequests_CheckedChanged(object sender, EventArgs e)
        {
            if (checkboxShowCompletedRequests.Checked == true)
            {
                //Loads the list of completed customer requests
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = "SELECT RequestID, ServiceName, NumofRequests, CustomerUserID, WorkerUserID, Status, Urgent, DateRequested FROM Requests WHERE Status = 'Completed' ORDER BY Urgent DESC";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                    DataTable table = new DataTable();
                    table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dataAdapter.Fill(table);
                    datagridviewRequestStatuses.ReadOnly = true;
                    datagridviewRequestStatuses.DataSource = table;
                }
            }
            else
            {
                //Loads the list of incomplete customer requests
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = "SELECT RequestID, ServiceName, NumofRequests, CustomerUserID, WorkerUserID, Status, Urgent, DateRequested FROM Requests WHERE Status != 'Completed' ORDER BY Urgent DESC";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                    DataTable table = new DataTable();
                    table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dataAdapter.Fill(table);
                    datagridviewRequestStatuses.ReadOnly = true;
                    datagridviewRequestStatuses.DataSource = table;
                }
            }
        }
    }
}