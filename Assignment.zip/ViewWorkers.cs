﻿using Manager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_Combined
{
    public partial class ViewWorkers : Form
    {
        string username;
        public ViewWorkers(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private void btnExitViewWorkers_Click(object sender, EventArgs e)
        {
            ManagerPage managerpage = new ManagerPage(username);
            managerpage.Show();
            this.Close();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = "SELECT * FROM Users WHERE Role = 'Worker'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                DataTable table = new DataTable();
                table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(table);
                datagridviewWorkerList.ReadOnly = true;
                datagridviewWorkerList.DataSource = table;
            }
        }
    }
}
