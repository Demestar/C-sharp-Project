﻿namespace Assignment
{
    partial class EditUserProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExitUpdateUserProfile = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.cmbRole = new System.Windows.Forms.ComboBox();
            this.lblRole = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblfullname = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblCreateUser = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.rbFemale = new System.Windows.Forms.CheckBox();
            this.rbMale = new System.Windows.Forms.CheckBox();
            this.lblUserID = new System.Windows.Forms.Label();
            this.txtUserID = new System.Windows.Forms.TextBox();
            this.btnLoadUser = new System.Windows.Forms.Button();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.panelGender = new System.Windows.Forms.Panel();
            this.lblUpdateUserProfileMsg = new System.Windows.Forms.Label();
            this.panelGender.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnExitUpdateUserProfile
            // 
            this.btnExitUpdateUserProfile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExitUpdateUserProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExitUpdateUserProfile.Location = new System.Drawing.Point(725, 497);
            this.btnExitUpdateUserProfile.Margin = new System.Windows.Forms.Padding(6);
            this.btnExitUpdateUserProfile.Name = "btnExitUpdateUserProfile";
            this.btnExitUpdateUserProfile.Size = new System.Drawing.Size(178, 85);
            this.btnExitUpdateUserProfile.TabIndex = 29;
            this.btnExitUpdateUserProfile.Text = "Exit";
            this.btnExitUpdateUserProfile.UseVisualStyleBackColor = false;
            this.btnExitUpdateUserProfile.Click += new System.EventHandler(this.btnExitUpdateUserProfile_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUpdate.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnUpdate.Location = new System.Drawing.Point(370, 495);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(6);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(178, 85);
            this.btnUpdate.TabIndex = 28;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtFullName
            // 
            this.txtFullName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtFullName.Location = new System.Drawing.Point(548, 263);
            this.txtFullName.Margin = new System.Windows.Forms.Padding(6);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(258, 31);
            this.txtFullName.TabIndex = 27;
            // 
            // txtPassword
            // 
            this.txtPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPassword.Location = new System.Drawing.Point(548, 306);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(6);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(258, 31);
            this.txtPassword.TabIndex = 26;
            // 
            // cmbRole
            // 
            this.cmbRole.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbRole.FormattingEnabled = true;
            this.cmbRole.Items.AddRange(new object[] {
            "Admin",
            "Manager",
            "Worker",
            "Customer"});
            this.cmbRole.Location = new System.Drawing.Point(548, 442);
            this.cmbRole.Margin = new System.Windows.Forms.Padding(6);
            this.cmbRole.Name = "cmbRole";
            this.cmbRole.Size = new System.Drawing.Size(210, 33);
            this.cmbRole.TabIndex = 23;
            // 
            // lblRole
            // 
            this.lblRole.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRole.Location = new System.Drawing.Point(408, 436);
            this.lblRole.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(158, 44);
            this.lblRole.TabIndex = 21;
            this.lblRole.Text = "Role:";
            this.lblRole.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGender
            // 
            this.lblGender.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblGender.Location = new System.Drawing.Point(408, 352);
            this.lblGender.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(158, 44);
            this.lblGender.TabIndex = 20;
            this.lblGender.Text = "Gender:";
            this.lblGender.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPhone
            // 
            this.lblPhone.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPhone.Location = new System.Drawing.Point(408, 396);
            this.lblPhone.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(158, 44);
            this.lblPhone.TabIndex = 19;
            this.lblPhone.Text = "Phone:";
            this.lblPhone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPassword
            // 
            this.lblPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPassword.Location = new System.Drawing.Point(354, 299);
            this.lblPassword.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(194, 44);
            this.lblPassword.TabIndex = 18;
            this.lblPassword.Text = "New Password:";
            this.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblfullname
            // 
            this.lblfullname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblfullname.Location = new System.Drawing.Point(340, 256);
            this.lblfullname.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblfullname.Name = "lblfullname";
            this.lblfullname.Size = new System.Drawing.Size(226, 38);
            this.lblfullname.TabIndex = 17;
            this.lblfullname.Text = "New Full Name:";
            this.lblfullname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUsername
            // 
            this.lblUsername.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblUsername.Location = new System.Drawing.Point(354, 210);
            this.lblUsername.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(196, 44);
            this.lblUsername.TabIndex = 16;
            this.lblUsername.Text = "New Username:";
            this.lblUsername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCreateUser
            // 
            this.lblCreateUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCreateUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateUser.Location = new System.Drawing.Point(358, 71);
            this.lblCreateUser.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCreateUser.Name = "lblCreateUser";
            this.lblCreateUser.Size = new System.Drawing.Size(498, 113);
            this.lblCreateUser.TabIndex = 15;
            this.lblCreateUser.Text = "Update User Profile";
            this.lblCreateUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtUsername
            // 
            this.txtUsername.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtUsername.Location = new System.Drawing.Point(548, 216);
            this.txtUsername.Margin = new System.Windows.Forms.Padding(6);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(258, 31);
            this.txtUsername.TabIndex = 24;
            // 
            // rbFemale
            // 
            this.rbFemale.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rbFemale.AutoSize = true;
            this.rbFemale.Location = new System.Drawing.Point(109, 6);
            this.rbFemale.Margin = new System.Windows.Forms.Padding(6);
            this.rbFemale.Name = "rbFemale";
            this.rbFemale.Size = new System.Drawing.Size(115, 29);
            this.rbFemale.TabIndex = 16;
            this.rbFemale.Text = "Female";
            this.rbFemale.UseVisualStyleBackColor = true;
            // 
            // rbMale
            // 
            this.rbMale.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rbMale.AutoSize = true;
            this.rbMale.Location = new System.Drawing.Point(6, 6);
            this.rbMale.Margin = new System.Windows.Forms.Padding(6);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(91, 29);
            this.rbMale.TabIndex = 15;
            this.rbMale.Text = "Male";
            this.rbMale.UseVisualStyleBackColor = true;
            // 
            // lblUserID
            // 
            this.lblUserID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblUserID.Location = new System.Drawing.Point(434, 173);
            this.lblUserID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(116, 37);
            this.lblUserID.TabIndex = 34;
            this.lblUserID.Text = "UserID:";
            this.lblUserID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtUserID
            // 
            this.txtUserID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtUserID.Location = new System.Drawing.Point(548, 176);
            this.txtUserID.Margin = new System.Windows.Forms.Padding(6);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Size = new System.Drawing.Size(66, 31);
            this.txtUserID.TabIndex = 35;
            this.txtUserID.TextChanged += new System.EventHandler(this.txtUserID_TextChanged);
            // 
            // btnLoadUser
            // 
            this.btnLoadUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnLoadUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLoadUser.Location = new System.Drawing.Point(631, 172);
            this.btnLoadUser.Margin = new System.Windows.Forms.Padding(6);
            this.btnLoadUser.Name = "btnLoadUser";
            this.btnLoadUser.Size = new System.Drawing.Size(157, 44);
            this.btnLoadUser.TabIndex = 37;
            this.btnLoadUser.Text = "Load User";
            this.btnLoadUser.UseVisualStyleBackColor = false;
            this.btnLoadUser.Click += new System.EventHandler(this.btnLoadUser_Click);
            // 
            // txtPhone
            // 
            this.txtPhone.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPhone.Location = new System.Drawing.Point(548, 403);
            this.txtPhone.Margin = new System.Windows.Forms.Padding(6);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(258, 31);
            this.txtPhone.TabIndex = 38;
            // 
            // panelGender
            // 
            this.panelGender.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelGender.Controls.Add(this.rbMale);
            this.panelGender.Controls.Add(this.rbFemale);
            this.panelGender.Location = new System.Drawing.Point(548, 356);
            this.panelGender.Name = "panelGender";
            this.panelGender.Size = new System.Drawing.Size(226, 38);
            this.panelGender.TabIndex = 39;
            // 
            // lblUpdateUserProfileMsg
            // 
            this.lblUpdateUserProfileMsg.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblUpdateUserProfileMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateUserProfileMsg.Location = new System.Drawing.Point(302, 237);
            this.lblUpdateUserProfileMsg.Name = "lblUpdateUserProfileMsg";
            this.lblUpdateUserProfileMsg.Size = new System.Drawing.Size(685, 183);
            this.lblUpdateUserProfileMsg.TabIndex = 40;
            this.lblUpdateUserProfileMsg.Text = "Please enter the user ID and load the user before proceeding";
            this.lblUpdateUserProfileMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EditUserProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.lblUpdateUserProfileMsg);
            this.Controls.Add(this.panelGender);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.btnLoadUser);
            this.Controls.Add(this.txtUserID);
            this.Controls.Add(this.lblUserID);
            this.Controls.Add(this.btnExitUpdateUserProfile);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtFullName);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.cmbRole);
            this.Controls.Add(this.lblRole);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblfullname);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lblCreateUser);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EditUserProfile";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit User Profile(Admin)";
            this.Load += new System.EventHandler(this.EditUserProfile_Load);
            this.panelGender.ResumeLayout(false);
            this.panelGender.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExitUpdateUserProfile;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.ComboBox cmbRole;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblfullname;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblCreateUser;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.CheckBox rbFemale;
        private System.Windows.Forms.CheckBox rbMale;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.TextBox txtUserID;
        private System.Windows.Forms.Button btnLoadUser;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Panel panelGender;
        private System.Windows.Forms.Label lblUpdateUserProfileMsg;
    }
}