﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment___Customer
{
    public partial class ViewRequestedServices : Form
    {
        int UserID;
        string username;
        public ViewRequestedServices(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private void btnExitViewRequestedServices_Click(object sender, EventArgs e)
        {
            CustomerMenu cm = new CustomerMenu(username);
            cm.Show();
            this.Close();
        }

        private void ViewRequestedServices_Load(object sender, EventArgs e)
        {
            checkboxShowCompletedRequests.Checked = false;

            //Gets the customer's user id
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = $"SELECT * FROM Users WHERE Username = '{username}'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectCommand, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                    while (reader.Read())
                    {
                        UserID = reader.GetInt32(0);
                    }
                connection.Close();
            }

            //Loads the list of incomplete requests based on the customer's user id
            connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            selectCommand = $"SELECT RequestID, ServiceName, NumofRequests, Price, Status, Urgent, DateRequested FROM Requests WHERE CustomerUserID = {UserID} AND Status != 'Completed' ORDER BY DateRequested";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                DataTable table = new DataTable();
                table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(table);
                datagridviewRequestedServices.ReadOnly = true;
                datagridviewRequestedServices.DataSource = table;
            }
        }

        private void checkboxShowCompletedRequests_CheckedChanged(object sender, EventArgs e)
        {
            if (checkboxShowCompletedRequests.Checked == true)
            {
                //Loads the list of completed requests based on the customer's user id
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"SELECT RequestID, ServiceName, NumofRequests, Price, Status, Urgent, DateRequested FROM Requests WHERE CustomerUserID = {UserID} AND Status = 'Completed' ORDER BY DateRequested";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                    DataTable table = new DataTable();
                    table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dataAdapter.Fill(table);
                    datagridviewRequestedServices.ReadOnly = true;
                    datagridviewRequestedServices.DataSource = table;
                }
            }
            else
            {
                //Loads the list of incomplete requests based on the customer's user id
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"SELECT RequestID, ServiceName, NumofRequests, Price, Status, Urgent, DateRequested FROM Requests WHERE CustomerUserID = {UserID} AND Status != 'Completed' ORDER BY DateRequested";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                    DataTable table = new DataTable();
                    table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dataAdapter.Fill(table);
                    datagridviewRequestedServices.ReadOnly = true;
                    datagridviewRequestedServices.DataSource = table;
                }
            }
        }

        private void btnCancelRequest_Click(object sender, EventArgs e)
        {
            bool cancelRequest = true;

            //Validates the input
            if (String.IsNullOrEmpty(txtboxRequestID.Text))
            {
                MessageBox.Show("Please provide a request ID!");
                cancelRequest = false;
            }
            else
            {
                try
                {
                    int.Parse(txtboxRequestID.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid request ID provided!");
                    cancelRequest = false;
                }
            }

            //Validates if the request belongs to the user
            if (cancelRequest == true)
            {
                int RequestIDtoCheck = -1;
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"SELECT RequestID FROM Requests WHERE RequestID = {txtboxRequestID.Text} AND CustomerUserID = {UserID}";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(selectCommand, connection))
                        try
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                                while (reader.Read())
                                {
                                    RequestIDtoCheck = reader.GetInt32(0);
                                }
                            if (RequestIDtoCheck == int.Parse(txtboxRequestID.Text))
                            {
                                connection.Close();
                            }
                            else
                            {
                                connection.Close();
                                cancelRequest = false;
                                MessageBox.Show("That request does not belong to you!");
                            }
                        }
                        catch (Exception ex)
                        {
                            connection.Close();
                            cancelRequest = false;
                            MessageBox.Show("That request does not belong to you!");
                        }
                }
            }

            //Validates the status of that request
            if (cancelRequest == true)
            {
                string StatustoCheck = "Assigned";
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"SELECT Status FROM Requests WHERE RequestID = {txtboxRequestID.Text} AND CustomerUserID = {UserID}";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(selectCommand, connection))
                        try
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                                while (reader.Read())
                                {
                                    StatustoCheck = reader.GetString(0);
                                }
                            if (StatustoCheck == "New")
                            {
                                connection.Close();
                            }
                            else
                            {
                                connection.Close();
                                cancelRequest = false;
                                MessageBox.Show("That request cannot be canceled as it has already been assigned to a worker!");
                            }
                        }
                        catch (Exception ex)
                        {
                            connection.Close();
                            cancelRequest = false;
                            MessageBox.Show("That request cannot be canceled as it has already been assigned to a worker!");
                        }
                }

                //Cancels the request
                if (cancelRequest == true)
                {
                    connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    selectCommand = $"DELETE FROM Requests WHERE RequestID = {txtboxRequestID.Text}";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(selectCommand, connection);

                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        connection.Close();

                    }
                    MessageBox.Show("Request successfully canceled!");
                }

                //Updates the data grid view
                if (cancelRequest == true)
                {
                    checkboxShowCompletedRequests.Checked = false;

                    //Loads the list of incomplete requests based on the customer's user id
                    connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    selectCommand = $"SELECT RequestID, ServiceName, NumofRequests, Price, Status, Urgent, DateRequested FROM Requests WHERE CustomerUserID = {UserID} ORDER BY DateRequested";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                        SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                        DataTable table = new DataTable();
                        table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                        dataAdapter.Fill(table);
                        datagridviewRequestedServices.ReadOnly = true;
                        datagridviewRequestedServices.DataSource = table;
                    }
                }
            }
        }
    }
}
