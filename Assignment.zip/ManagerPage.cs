﻿using Assignment;
using Assignment_Combined;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Manager
{
    public partial class ManagerPage : Form
    {
        string username;
        public ManagerPage(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private void btnCheckRequestStatus_Click(object sender, EventArgs e)
        {
            ViewCustomerRequests checkrequeststatus = new ViewCustomerRequests(username);
            checkrequeststatus.Show();
            this.Hide();
        }

        private void btnAssignJobs_Click(object sender, EventArgs e)
        {
            AssignRequests assignworkers = new AssignRequests(username);
            assignworkers.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void btnUpdateProfile_Click(object sender, EventArgs e)
        {
            UpdateSelfProfile updateselfprofile = new UpdateSelfProfile(username, "Manager");
            updateselfprofile.Show();
            this.Hide();
        }

        private void btnViewWorkers_Click(object sender, EventArgs e)
        {
            ViewWorkers viewworkers = new ViewWorkers(username);
            viewworkers.Show();
            this.Hide();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            lblWelcomeManager.Text = $"Welcome {username}! What would you like to do?";
        }

    }
}