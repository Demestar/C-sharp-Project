﻿using Assignment_Combined;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Assignment
{

    public partial class EditUserProfile : Form
    {
        string adminusername;
        ViewUsersStatic viewusersstatic = new ViewUsersStatic();

        string UserIDtoEdit;
        string UsernametoEdit;
        string FullnametoEdit;
        string PasswordtoEdit;
        string GendertoEdit;
        string PhonetoEdit;
        string RoletoEdit;
        public EditUserProfile(string AdminUsername)
        {
            InitializeComponent();
            adminusername = AdminUsername;
        }

        //This method validates whether the username already exists in the database or not
        public bool ValidateUsername(string UserID, string Username)
        {
            string UsernametoCheck = null;
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = $"SELECT Username FROM Users WHERE Username = '{Username}' AND UserID != {UserID}";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectCommand, connection))
                try
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    while (reader.Read())
                    {
                        UsernametoCheck = reader.GetString(0);
                    }
                    if (!string.IsNullOrEmpty(UsernametoCheck))
                    {
                        connection.Close();
                        return true;
                    }
                    else
                    {
                        connection.Close();
                        return false;
                    }
                       
                }
                catch (Exception ex)
                {
                        connection.Close();
                        return false;
                }
            }
        }

        private void btnExitUpdateUserProfile_Click(object sender, EventArgs e)
        {
            AdminPage adminpage = new AdminPage(adminusername);
            viewusersstatic.Close();
            adminpage.Show();
            this.Close();
        }

        private void EditUserProfile_Load(object sender, EventArgs e)
        {
            viewusersstatic.Show();

            lblUsername.Visible = false;
            txtUsername.Visible = false;
            lblfullname.Visible = false;
            txtFullName.Visible = false;
            lblPassword.Visible = false;
            txtPassword.Visible = false;
            lblGender.Visible = false;
            rbMale.Visible = false;
            rbFemale.Visible = false;
            panelGender.Visible = false;
            lblPhone.Visible = false;
            txtPhone.Visible = false;
            lblRole.Visible = false;
            cmbRole.Visible = false;
            lblUpdateUserProfileMsg.Visible = true;
        }

        private void btnLoadUser_Click(object sender, EventArgs e)
        {
           //Attempts to get the user information based on the user id provided
            UserIDtoEdit = txtUserID.Text;
            UsernametoEdit = txtUsername.Text;
            FullnametoEdit = txtFullName.Text;
            PasswordtoEdit = txtPassword.Text;
            GendertoEdit = rbMale.Text;
            PhonetoEdit = txtPhone.Text;
            RoletoEdit = cmbRole.Text;

            bool InvalidUserIDWarningShown = false;

            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = $"SELECT * FROM Users WHERE UserID = {UserIDtoEdit}";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectCommand, connection))
                {
                    // Execute the command and read the data
                    try
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                            while (reader.Read())
                            {
                                // Access data from each column
                                FullnametoEdit = reader.GetString(1);
                                UsernametoEdit = reader.GetString(2);
                                PasswordtoEdit = reader.GetString(3);
                                PhonetoEdit = reader.GetString(4);
                                GendertoEdit = reader.GetString(5);
                                RoletoEdit = reader.GetString(6);
                            }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Invalid user ID provided!");
                        InvalidUserIDWarningShown = true;
                    }
                }
                connection.Close();
            }

            if (!string.IsNullOrEmpty(FullnametoEdit))
            {
                lblUsername.Visible = true;
                txtUsername.Visible = true;
                lblfullname.Visible = true;
                txtFullName.Visible = true;
                lblPassword.Visible = true;
                txtPassword.Visible = true;
                lblGender.Visible = true;
                rbMale.Visible = true;
                rbFemale.Visible = true;
                panelGender.Visible = true;
                lblPhone.Visible = true;
                txtPhone.Visible = true;
                lblRole.Visible = true;
                cmbRole.Visible = true;
                lblUpdateUserProfileMsg.Visible = false;

                txtUsername.Text = UsernametoEdit;
                txtFullName.Text = FullnametoEdit;
                txtPassword.Text = PasswordtoEdit;
                txtPhone.Text = PhonetoEdit;

                if (GendertoEdit == "Male")
                {
                    rbMale.Checked = true;
                    rbFemale.Checked = false;
                }
                else if (GendertoEdit == "Female")
                {
                    rbMale.Checked = false;
                    rbFemale.Checked = true;
                }
                else
                {
                    rbMale.Checked = false;
                    rbFemale.Checked = false;
                }

                if (RoletoEdit == "Admin")
                {
                    cmbRole.SelectedIndex = 0;
                }
                else if (RoletoEdit == "Manager")
                {
                    cmbRole.SelectedIndex = 1;
                }
                else if (RoletoEdit == "Worker")
                {
                    cmbRole.SelectedIndex = 2;
                }
                else if (RoletoEdit == "Customer")
                {
                    cmbRole.SelectedIndex = 3;
                }
                else
                {
                    cmbRole.SelectedIndex = -1;
                }
            }
            else
            {
                if (InvalidUserIDWarningShown == false)
                {
                    MessageBox.Show("Invalid user ID provided!");
                    InvalidUserIDWarningShown = true;
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtUsername.Text) || String.IsNullOrEmpty(txtFullName.Text) || String.IsNullOrEmpty(txtPassword.Text) || String.IsNullOrEmpty(txtPhone.Text) || cmbRole.SelectedIndex == -1)
            {
                MessageBox.Show("Some of the fields are empty/invalid!");
            }
            else if ((rbMale.Checked == true && rbFemale.Checked == true) || (rbMale.Checked == false && rbFemale.Checked == false))
            {
                MessageBox.Show("Some of the fields are empty/invalid!");
            }
            else if (ValidateUsername(UserIDtoEdit, txtUsername.Text) == true)
            {
                MessageBox.Show("That username is already taken!");
            }
            else
            {
                try
                {
                    int ConvertPhonetoInt = int.Parse(txtPhone.Text);
                    MessageBox.Show("Profile updated successfully!");

                    UsernametoEdit = txtUsername.Text;
                    FullnametoEdit = txtFullName.Text;
                    PasswordtoEdit = txtPassword.Text;
                    PhonetoEdit = txtPhone.Text;
                    RoletoEdit = cmbRole.Text;
                    if (rbMale.Checked == true)
                    {
                        GendertoEdit = "Male";
                    }
                    else
                    {
                        GendertoEdit = "Female";
                    }

                    //Code for updating the profile in the database
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"UPDATE Users SET FullName = '{FullnametoEdit}', Username = '{UsernametoEdit}', Password = '{PasswordtoEdit}', Phone = {ConvertPhonetoInt}, Gender = '{GendertoEdit}', Role = '{RoletoEdit}' WHERE UserID = {UserIDtoEdit}";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(selectCommand, connection);

                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        connection.Close();

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Some of the fields are empty/invalid!");
                }
            }
        }

        private void txtUserID_TextChanged(object sender, EventArgs e)
        {
            UsernametoEdit = "";
            FullnametoEdit = "";
            PasswordtoEdit = "";
            PhonetoEdit = "";
            GendertoEdit = "";
            RoletoEdit = "";

            txtUsername.Text = "";
            txtFullName.Text = "";
            txtPassword.Text = "";
            txtPhone.Text = "";
            rbMale.Checked = false;
            rbFemale.Checked = false;
            cmbRole.SelectedIndex = -1;
        }
    }
}
