﻿using Assignment;
using Assignment_Combined;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Worker
{
    public partial class WorkerPage : Form
    {
        string username;
        public WorkerPage(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private void btnViewRequests_Click(object sender, EventArgs e)
        {
            ViewAssignedRequests viewassignedrequests = new ViewAssignedRequests(username);
            viewassignedrequests.Show();
            this.Hide();
        }

        private void btnUpdateRequests_Click(object sender, EventArgs e)
        {
            UpdateRequestStatus updaterequests = new UpdateRequestStatus(username);
            updaterequests.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void btnUpdateProfile_Click(object sender, EventArgs e)
        {
            UpdateSelfProfile updateselfprofile = new UpdateSelfProfile(username, "Worker");
            updateselfprofile.Show();
            this.Hide();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            lblWelcomeWorker.Text = $"Welcome, {username}! What would you like to do?";
        }
    }
}
