﻿using Assignment;
using Assignment_Combined;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Manager
{
    public partial class AssignRequests : Form
    {
        ViewWorkersStatic viewworkersstatic = new ViewWorkersStatic();
        string username;
        public AssignRequests(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            ManagerPage managerpage = new ManagerPage(username);
            managerpage.Show();
            viewworkersstatic.Hide();
            this.Close();
        }

        private void btnAssign_Click(object sender, EventArgs e)
        {
            bool shouldAssign = true;

            if (String.IsNullOrEmpty(txtRequestID.Text) || String.IsNullOrEmpty(txtWorkerID.Text))
            {
                MessageBox.Show("One or both of the fields are empty!");
                shouldAssign = false;
            }
            else
            {
                try
                {
                    int.Parse(txtRequestID.Text);
                    int.Parse(txtWorkerID.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid request ID or worker ID provided!");
                    shouldAssign = false;
                }
            }

            //Validates the existance of the worker
            if (shouldAssign == true)
            {
                int WorkerIDtoCheck = -1;
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"SELECT UserID FROM Users WHERE Role = 'Worker' AND UserID = {txtWorkerID.Text}";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(selectCommand, connection))
                        try
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                                while (reader.Read())
                                {
                                    WorkerIDtoCheck = reader.GetInt32(0);
                                }
                            if (WorkerIDtoCheck == -1)
                            {
                                connection.Close();
                                shouldAssign = false;
                                MessageBox.Show("That worker does not exist!");
                            }
                            else
                            {
                                connection.Close();
                            }
                        }
                        catch (Exception ex)
                        {
                            connection.Close();
                            shouldAssign = false;
                            MessageBox.Show("That worker does not exist!");
                        }
                }
            }

            //Validates the existance of the request
            if (shouldAssign == true)
            {
                int RequestIDtoCheck = -1;
                int WorkerIDtoCheck = -1;
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"SELECT RequestID, WorkerUserID FROM Requests WHERE RequestID = {txtRequestID.Text}";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(selectCommand, connection))
                        try
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                                while (reader.Read())
                                {
                                    RequestIDtoCheck = reader.GetInt32(0);
                                    WorkerIDtoCheck = reader.GetInt32(1);
                                }
                            if (RequestIDtoCheck == -1)
                            {
                                connection.Close();
                                shouldAssign = false;
                                MessageBox.Show("That request does not exist!");
                            }
                            else if (WorkerIDtoCheck != -1)
                            {
                                connection.Close();
                                shouldAssign = false;
                                MessageBox.Show("That request has already a worker assigned!");
                            }
                            else
                            {
                                connection.Close();
                            }
                        }
                        catch (Exception ex)
                        {
                            connection.Close();
                        }
                }
            }

            //Assigns the worker to the request
            if (shouldAssign == true)
            {
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"UPDATE Requests SET WorkerUserID = {txtWorkerID.Text}, Status = 'Assigned' WHERE RequestID = {txtRequestID.Text}";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(selectCommand, connection);

                    connection.Open();
                    int affectedRows = command.ExecuteNonQuery();
                    connection.Close();

                }
                MessageBox.Show("Worker successfully assigned!");
            }

            if (shouldAssign == true)
            {
                //Loads the list of incomplete customer requests
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = "SELECT RequestID, ServiceName, NumofRequests, CustomerUserID, WorkerUserID, Status, Urgent, DateRequested FROM Requests WHERE Status = 'New' ORDER BY Urgent DESC";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                    DataTable table = new DataTable();
                    table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dataAdapter.Fill(table);
                    datagridviewRequestStatuses.ReadOnly = true;
                    datagridviewRequestStatuses.DataSource = table;
                }
            }
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            viewworkersstatic.Show();

            //Loads the list of incomplete customer requests
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = "SELECT RequestID, ServiceName, NumofRequests, CustomerUserID, WorkerUserID, Status, Urgent, DateRequested FROM Requests WHERE Status = 'New' ORDER BY Urgent DESC";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                DataTable table = new DataTable();
                table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(table);
                datagridviewRequestStatuses.ReadOnly = true;
                datagridviewRequestStatuses.DataSource = table;
            }
        }
    }
}