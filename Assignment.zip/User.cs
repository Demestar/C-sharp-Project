﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    public class User
    {
        private int _UserID;
        private string _Fullname;
        private string _Username;
        private string _Password;
        private string _Phone;
        private string _Gender;
        private string _Role;

        public User()
        {
            _UserID = 0;
            _Fullname = string.Empty;
            _Username = string.Empty;
            _Password = string.Empty;
            _Phone = string.Empty;
            _Gender = string.Empty;
            _Role = string.Empty;
        }

        public User(int userID, string fullname, string username, string password, string phone, string gender, string role)
        {
            _UserID = userID;
            _Fullname = fullname;
            _Username = username;
            _Password = password;
            _Phone = phone;
            _Gender = gender;
            _Role = role;
        }

        public int UserID
        {
            get { return _UserID; }
        }
        public string Fullname
        {
            get { return _Fullname; }
            set { _Fullname = value; }
        }
        public string Username
        {
            get { return _Username; }
            set { _Username = value; }
        }
        public string Password
        {
            get { return _Password; }
            set { _Password = value; }
        }
        public string Phone
        {
            get { return _Phone; }
            set { _Phone = value; }
        }
        public string Gender
        {
            get { return _Gender; }
            set { _Gender = value; }
        }
        public string Role
        {
            get { return _Role; }
            set { _Role = value; }
        }
    }
}
