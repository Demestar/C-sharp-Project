﻿using Assignment_Combined;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class DelUserProfile : Form
    {
        string username;
        int UserID;
        int UserIDtoDelete;
        public DelUserProfile(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private void btnExitDeleteUserProfile_Click(object sender, EventArgs e)
        {
            AdminPage adminpage = new AdminPage(username);
            adminpage.Show();
            this.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            bool shouldDelete = true;

            //Validation
            try
            {
                int.Parse(txtUserIDtoDelete.Text);
                UserIDtoDelete = int.Parse(txtUserIDtoDelete.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Invalid User ID provided!");
                shouldDelete = false;
            }

            //Ensures that the user is not deleting themselves
            if (shouldDelete == true && UserIDtoDelete == UserID)
            {
                MessageBox.Show("You cannot delete yourself!");
                shouldDelete = false;
            }

            //Proceeds to delete the user
            if (shouldDelete == true)
            {
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"DELETE FROM Users WHERE UserID = {UserIDtoDelete}";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(selectCommand, connection);

                    connection.Open();
                    int affectedRows = command.ExecuteNonQuery();
                    connection.Close();
                }

                MessageBox.Show("User successfully deleted!");

                //Refreshes the form
                connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                selectCommand = "SELECT * FROM Users ORDER BY Role";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                    DataTable table = new DataTable();
                    table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dataAdapter.Fill(table);
                    datagridviewUserList.ReadOnly = true;
                    datagridviewUserList.DataSource = table;
                }
            }
        }

        private void DelUserProfile_Load(object sender, EventArgs e)
        {
            //Gets the admin's user id
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = $"SELECT * FROM Users WHERE Username = '{username}'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectCommand, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                    while (reader.Read())
                    {
                        UserID = reader.GetInt32(0);
                    }
                connection.Close();
            }

            //Loads the list of users
            connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            selectCommand = "SELECT * FROM Users ORDER BY Role";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                DataTable table = new DataTable();
                table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(table);
                datagridviewUserList.ReadOnly = true;
                datagridviewUserList.DataSource = table;
            }
        }
    }
}
