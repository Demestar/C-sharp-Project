﻿namespace Worker
{
    partial class ViewAssignedRequests
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.datagridviewAssignedRequests = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnExitListofRequests = new System.Windows.Forms.Button();
            this.checkboxShowCompletedRequests = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewAssignedRequests)).BeginInit();
            this.SuspendLayout();
            // 
            // datagridviewAssignedRequests
            // 
            this.datagridviewAssignedRequests.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datagridviewAssignedRequests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewAssignedRequests.Location = new System.Drawing.Point(141, 118);
            this.datagridviewAssignedRequests.Margin = new System.Windows.Forms.Padding(6);
            this.datagridviewAssignedRequests.Name = "datagridviewAssignedRequests";
            this.datagridviewAssignedRequests.RowHeadersWidth = 82;
            this.datagridviewAssignedRequests.Size = new System.Drawing.Size(967, 442);
            this.datagridviewAssignedRequests.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(167, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(899, 73);
            this.label1.TabIndex = 1;
            this.label1.Text = "Here is the list of requests that you\'ve been assigned";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExitListofRequests
            // 
            this.btnExitListofRequests.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExitListofRequests.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExitListofRequests.Location = new System.Drawing.Point(793, 580);
            this.btnExitListofRequests.Name = "btnExitListofRequests";
            this.btnExitListofRequests.Size = new System.Drawing.Size(180, 86);
            this.btnExitListofRequests.TabIndex = 2;
            this.btnExitListofRequests.Text = "Exit";
            this.btnExitListofRequests.UseVisualStyleBackColor = false;
            this.btnExitListofRequests.Click += new System.EventHandler(this.btnExitListofRequests_Click);
            // 
            // checkboxShowCompletedRequests
            // 
            this.checkboxShowCompletedRequests.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkboxShowCompletedRequests.AutoSize = true;
            this.checkboxShowCompletedRequests.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.checkboxShowCompletedRequests.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkboxShowCompletedRequests.Location = new System.Drawing.Point(199, 601);
            this.checkboxShowCompletedRequests.Name = "checkboxShowCompletedRequests";
            this.checkboxShowCompletedRequests.Size = new System.Drawing.Size(416, 41);
            this.checkboxShowCompletedRequests.TabIndex = 6;
            this.checkboxShowCompletedRequests.Text = "Show completed requests";
            this.checkboxShowCompletedRequests.UseVisualStyleBackColor = false;
            this.checkboxShowCompletedRequests.CheckedChanged += new System.EventHandler(this.checkboxShowCompletedRequests_CheckedChanged);
            // 
            // ViewAssignedRequests
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.checkboxShowCompletedRequests);
            this.Controls.Add(this.btnExitListofRequests);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.datagridviewAssignedRequests);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "ViewAssignedRequests";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewAssignedRequests";
            this.Load += new System.EventHandler(this.Form12_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewAssignedRequests)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView datagridviewAssignedRequests;
        private System.Windows.Forms.DataGridViewTextBoxColumn requestIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numofRequestsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerUserIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnExitListofRequests;
        private System.Windows.Forms.CheckBox checkboxShowCompletedRequests;
    }
}