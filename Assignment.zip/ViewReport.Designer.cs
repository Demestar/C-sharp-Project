﻿namespace Assignment
{
    partial class ViewReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.datagridviewReport = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.cbReportType = new System.Windows.Forms.ComboBox();
            this.cbYear = new System.Windows.Forms.ComboBox();
            this.lblYear = new System.Windows.Forms.Label();
            this.cbMonth = new System.Windows.Forms.ComboBox();
            this.lblMonth = new System.Windows.Forms.Label();
            this.btnExitViewReport = new System.Windows.Forms.Button();
            this.btnViewReport = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewReport)).BeginInit();
            this.SuspendLayout();
            // 
            // datagridviewReport
            // 
            this.datagridviewReport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datagridviewReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewReport.Location = new System.Drawing.Point(453, 93);
            this.datagridviewReport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.datagridviewReport.Name = "datagridviewReport";
            this.datagridviewReport.RowHeadersWidth = 51;
            this.datagridviewReport.RowTemplate.Height = 24;
            this.datagridviewReport.Size = new System.Drawing.Size(700, 502);
            this.datagridviewReport.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.Location = new System.Drawing.Point(111, 97);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(228, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select Report to View";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbReportType
            // 
            this.cbReportType.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbReportType.FormattingEnabled = true;
            this.cbReportType.Items.AddRange(new object[] {
            "Yearly Report",
            "Service req. Report",
            "Customer Report"});
            this.cbReportType.Location = new System.Drawing.Point(116, 146);
            this.cbReportType.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbReportType.Name = "cbReportType";
            this.cbReportType.Size = new System.Drawing.Size(230, 33);
            this.cbReportType.TabIndex = 2;
            // 
            // cbYear
            // 
            this.cbYear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbYear.FormattingEnabled = true;
            this.cbYear.Items.AddRange(new object[] {
            "2024",
            "2025"});
            this.cbYear.Location = new System.Drawing.Point(116, 284);
            this.cbYear.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbYear.Name = "cbYear";
            this.cbYear.Size = new System.Drawing.Size(230, 33);
            this.cbYear.TabIndex = 6;
            // 
            // lblYear
            // 
            this.lblYear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblYear.Location = new System.Drawing.Point(111, 232);
            this.lblYear.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(214, 36);
            this.lblYear.TabIndex = 5;
            this.lblYear.Text = "Select Year to View";
            this.lblYear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbMonth
            // 
            this.cbMonth.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbMonth.FormattingEnabled = true;
            this.cbMonth.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.cbMonth.Location = new System.Drawing.Point(116, 422);
            this.cbMonth.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbMonth.Name = "cbMonth";
            this.cbMonth.Size = new System.Drawing.Size(230, 33);
            this.cbMonth.TabIndex = 8;
            // 
            // lblMonth
            // 
            this.lblMonth.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMonth.Location = new System.Drawing.Point(104, 371);
            this.lblMonth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(232, 36);
            this.lblMonth.TabIndex = 7;
            this.lblMonth.Text = "Select Month to View";
            this.lblMonth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExitViewReport
            // 
            this.btnExitViewReport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExitViewReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExitViewReport.Location = new System.Drawing.Point(248, 525);
            this.btnExitViewReport.Margin = new System.Windows.Forms.Padding(6);
            this.btnExitViewReport.Name = "btnExitViewReport";
            this.btnExitViewReport.Size = new System.Drawing.Size(165, 90);
            this.btnExitViewReport.TabIndex = 30;
            this.btnExitViewReport.Text = "Exit";
            this.btnExitViewReport.UseVisualStyleBackColor = false;
            this.btnExitViewReport.Click += new System.EventHandler(this.btnExitViewReport_Click);
            // 
            // btnViewReport
            // 
            this.btnViewReport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnViewReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnViewReport.Location = new System.Drawing.Point(65, 525);
            this.btnViewReport.Margin = new System.Windows.Forms.Padding(6);
            this.btnViewReport.Name = "btnViewReport";
            this.btnViewReport.Size = new System.Drawing.Size(149, 90);
            this.btnViewReport.TabIndex = 31;
            this.btnViewReport.Text = "View";
            this.btnViewReport.UseVisualStyleBackColor = false;
            this.btnViewReport.Click += new System.EventHandler(this.btnViewReport_Click);
            // 
            // ViewReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.btnViewReport);
            this.Controls.Add(this.btnExitViewReport);
            this.Controls.Add(this.cbMonth);
            this.Controls.Add(this.lblMonth);
            this.Controls.Add(this.cbYear);
            this.Controls.Add(this.lblYear);
            this.Controls.Add(this.cbReportType);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.datagridviewReport);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "ViewReport";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewReport";
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewReport)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView datagridviewReport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbReportType;
        private System.Windows.Forms.ComboBox cbYear;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.ComboBox cbMonth;
        private System.Windows.Forms.Label lblMonth;
        private System.Windows.Forms.Button btnExitViewReport;
        private System.Windows.Forms.Button btnViewReport;
    }
}