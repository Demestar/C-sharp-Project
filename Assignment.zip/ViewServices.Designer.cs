﻿namespace Assignment___Customer
{
    partial class ViewServices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblViewServices = new System.Windows.Forms.Label();
            this.btnExitViewServices = new System.Windows.Forms.Button();
            this.datagridviewViewServices = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewViewServices)).BeginInit();
            this.SuspendLayout();
            // 
            // lblViewServices
            // 
            this.lblViewServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblViewServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewServices.Location = new System.Drawing.Point(198, 53);
            this.lblViewServices.Name = "lblViewServices";
            this.lblViewServices.Size = new System.Drawing.Size(795, 66);
            this.lblViewServices.TabIndex = 1;
            this.lblViewServices.Text = "Here are the list of services we provide";
            this.lblViewServices.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExitViewServices
            // 
            this.btnExitViewServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExitViewServices.BackColor = System.Drawing.Color.IndianRed;
            this.btnExitViewServices.Location = new System.Drawing.Point(510, 590);
            this.btnExitViewServices.Name = "btnExitViewServices";
            this.btnExitViewServices.Size = new System.Drawing.Size(217, 78);
            this.btnExitViewServices.TabIndex = 2;
            this.btnExitViewServices.Text = "Exit";
            this.btnExitViewServices.UseVisualStyleBackColor = false;
            this.btnExitViewServices.Click += new System.EventHandler(this.btnExitViewServices_Click);
            // 
            // datagridviewViewServices
            // 
            this.datagridviewViewServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datagridviewViewServices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewViewServices.Location = new System.Drawing.Point(110, 134);
            this.datagridviewViewServices.Name = "datagridviewViewServices";
            this.datagridviewViewServices.RowHeadersWidth = 82;
            this.datagridviewViewServices.RowTemplate.Height = 33;
            this.datagridviewViewServices.Size = new System.Drawing.Size(1000, 437);
            this.datagridviewViewServices.TabIndex = 3;
            // 
            // ViewServices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.datagridviewViewServices);
            this.Controls.Add(this.btnExitViewServices);
            this.Controls.Add(this.lblViewServices);
            this.Name = "ViewServices";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewServices";
            this.Load += new System.EventHandler(this.ViewServices_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewViewServices)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblViewServices;
        private System.Windows.Forms.Button btnExitViewServices;
        private System.Windows.Forms.DataGridView datagridviewViewServices;
    }
}