﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment___Customer
{
    internal class Service
    {
        private int _ServiceIndex;
        private double _Fee;
        private double _Discount;
        private int _MinQuantityForDiscount;
        
        public Service(int ServiceIndex, double Fee, double Discount, int MinQuantityForDiscount)
        {
            _ServiceIndex = ServiceIndex;
            _Fee = Fee;
            _Discount = 1 - (Discount / 100);
            _MinQuantityForDiscount = MinQuantityForDiscount;
        }

        public Service(int ServiceIndex, double Fee)
        {
            _ServiceIndex = ServiceIndex;
            _Fee = Fee;
            _Discount = 0;
            _MinQuantityForDiscount = 0;
        }

        public double CalculatePrice(int Quantity)
        {
            double TotalFee = Quantity * _Fee;
            if (_Discount != 0)
            {
                if (Quantity > _MinQuantityForDiscount)
                {
                    TotalFee = TotalFee * _Discount;
                }
            }
            return TotalFee;
        }
    }
}
