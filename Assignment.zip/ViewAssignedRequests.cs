﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Worker
{
    public partial class ViewAssignedRequests : Form
    {
        int UserID;
        string username;
        public ViewAssignedRequests(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private void btnExitListofRequests_Click(object sender, EventArgs e)
        {
            WorkerPage workerpage = new WorkerPage(username);
            workerpage.Show();
            this.Close();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            checkboxShowCompletedRequests.Checked = false;

            //Gets the worker's user id
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = $"SELECT * FROM Users WHERE Username = '{username}'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectCommand, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                    while (reader.Read())
                    {
                        UserID = reader.GetInt32(0);
                    }
                connection.Close();
            }

            //Loads the list of assigned incomplete requests based on the worker's user id
            connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            selectCommand = $"SELECT RequestID, ServiceName, NumofRequests, Price, Status, Urgent, DateRequested FROM Requests WHERE WorkerUserID = {UserID} AND Status != 'Completed' ORDER BY DateRequested";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                DataTable table = new DataTable();
                table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(table);
                datagridviewAssignedRequests.ReadOnly = true;
                datagridviewAssignedRequests.DataSource = table;
            }
        }

        private void checkboxShowCompletedRequests_CheckedChanged(object sender, EventArgs e)
        {
            if (checkboxShowCompletedRequests.Checked == true)
            {
                //Loads the list of assigned completed requests based on the worker's user id
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"SELECT RequestID, ServiceName, NumofRequests, Price, Status, Urgent, DateRequested FROM Requests WHERE WorkerUserID = {UserID} AND Status = 'Completed' ORDER BY DateRequested";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                    DataTable table = new DataTable();
                    table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dataAdapter.Fill(table);
                    datagridviewAssignedRequests.ReadOnly = true;
                    datagridviewAssignedRequests.DataSource = table;
                }
            }
            else
            {
                //Loads the list of assigned incomplete requests based on the worker's user id
                string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                string selectCommand = $"SELECT RequestID, ServiceName, NumofRequests, Price, Status, Urgent, DateRequested FROM Requests WHERE WorkerUserID = {UserID} AND Status != 'Completed' ORDER BY DateRequested";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                    SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                    DataTable table = new DataTable();
                    table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dataAdapter.Fill(table);
                    datagridviewAssignedRequests.ReadOnly = true;
                    datagridviewAssignedRequests.DataSource = table;
                }
            }
        }
    }
}
