﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment
{
    public partial class ViewReport : Form
    {
        int year;
        string month;
        string username;
        public ViewReport(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        private void btnExitViewReport_Click(object sender, EventArgs e)
        {
            AdminPage adminpage = new AdminPage(username);
            adminpage.Show();
            this.Close();

        }

        private void btnViewReport_Click(object sender, EventArgs e)
        {
            if (cbReportType.SelectedIndex == -1 || cbYear.SelectedIndex == -1 || cbMonth.SelectedIndex == -1)
            {
                //Ensure that each combobox has a selected index
                MessageBox.Show("Some of the fields are empty!");
            }
            else
            {
                //Converting and storing the selected year and month into their respective variables
                year = int.Parse(cbYear.Text);
                month = cbMonth.Text;

                if (cbReportType.SelectedIndex == 0)
                {
                    //Code for creating yearly report based on year and month provided
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"SELECT * FROM YearlyReport WHERE Month = '{month}' AND Year = {year}";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                        SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                        DataTable table = new DataTable();
                        table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                        dataAdapter.Fill(table);
                        datagridviewReport.ReadOnly = true;
                        datagridviewReport.DataSource = table;
                    }
                }
                else if (cbReportType.SelectedIndex == 1)
                {
                    //Code for creating service request report based on year and month provided
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"SELECT * FROM ServiceReport WHERE Month = '{month}' AND Year = {year}";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                        SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                        DataTable table = new DataTable();
                        table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                        dataAdapter.Fill(table);
                        datagridviewReport.ReadOnly = true;
                        datagridviewReport.DataSource = table;
                    }
                }
                else
                {
                    //Code for creating customer report based on year and month provided
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"SELECT * FROM CustomerReport WHERE Month = '{month}' AND Year = {year}";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                        SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                        DataTable table = new DataTable();
                        table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                        dataAdapter.Fill(table);
                        datagridviewReport.ReadOnly = true;
                        datagridviewReport.DataSource = table;
                    }
                }
            }
        }
    }
}
