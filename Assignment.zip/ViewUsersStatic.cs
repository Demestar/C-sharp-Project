﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_Combined
{
    public partial class ViewUsersStatic : Form
    {
        public ViewUsersStatic()
        {
            InitializeComponent();
        }

        private void ViewUsersStatic_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = "SELECT * FROM Users ORDER BY Role";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                DataTable table = new DataTable();
                table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(table);
                datagridviewUserList.ReadOnly = true;
                datagridviewUserList.DataSource = table;
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = "SELECT * FROM Users ORDER BY Role";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCommand, connection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                DataTable table = new DataTable();
                table.Locale = System.Globalization.CultureInfo.InvariantCulture;
                dataAdapter.Fill(table);
                datagridviewUserList.ReadOnly = true;
                datagridviewUserList.DataSource = table;
            }
        }
    }
}
