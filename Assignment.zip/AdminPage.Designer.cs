﻿namespace Assignment
{
    partial class AdminPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWelcomeAdmin = new System.Windows.Forms.Label();
            this.btnGeneReport = new System.Windows.Forms.Button();
            this.btnAddNewUser = new System.Windows.Forms.Button();
            this.btnDeleteUser = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnUpdAdmin = new System.Windows.Forms.Button();
            this.btnUpdUser = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.btnUpdateUserProfile = new System.Windows.Forms.Button();
            this.btnViewUsers = new System.Windows.Forms.Button();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWelcomeAdmin
            // 
            this.lblWelcomeAdmin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblWelcomeAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcomeAdmin.Location = new System.Drawing.Point(345, 71);
            this.lblWelcomeAdmin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWelcomeAdmin.Name = "lblWelcomeAdmin";
            this.lblWelcomeAdmin.Size = new System.Drawing.Size(547, 97);
            this.lblWelcomeAdmin.TabIndex = 0;
            this.lblWelcomeAdmin.Text = "Welcome, User! What would you like to do?";
            this.lblWelcomeAdmin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnGeneReport
            // 
            this.btnGeneReport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGeneReport.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnGeneReport.Location = new System.Drawing.Point(236, 220);
            this.btnGeneReport.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnGeneReport.Name = "btnGeneReport";
            this.btnGeneReport.Size = new System.Drawing.Size(180, 80);
            this.btnGeneReport.TabIndex = 1;
            this.btnGeneReport.Text = "Generate Report";
            this.btnGeneReport.UseVisualStyleBackColor = false;
            this.btnGeneReport.Click += new System.EventHandler(this.btnGeneReport_Click);
            // 
            // btnAddNewUser
            // 
            this.btnAddNewUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAddNewUser.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddNewUser.Location = new System.Drawing.Point(933, 227);
            this.btnAddNewUser.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAddNewUser.Name = "btnAddNewUser";
            this.btnAddNewUser.Size = new System.Drawing.Size(180, 84);
            this.btnAddNewUser.TabIndex = 5;
            this.btnAddNewUser.Text = "Add New User";
            this.btnAddNewUser.UseVisualStyleBackColor = false;
            this.btnAddNewUser.Click += new System.EventHandler(this.btnAddNewUser_Click);
            // 
            // btnDeleteUser
            // 
            this.btnDeleteUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnDeleteUser.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDeleteUser.Location = new System.Drawing.Point(236, 323);
            this.btnDeleteUser.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnDeleteUser.Name = "btnDeleteUser";
            this.btnDeleteUser.Size = new System.Drawing.Size(180, 91);
            this.btnDeleteUser.TabIndex = 7;
            this.btnDeleteUser.Text = "Delete User";
            this.btnDeleteUser.UseVisualStyleBackColor = false;
            this.btnDeleteUser.Click += new System.EventHandler(this.btnDeleteUser_Click);
            // 
            // btnExit
            // 
            this.btnExit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExit.BackColor = System.Drawing.Color.LightCoral;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnExit.Location = new System.Drawing.Point(982, 566);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(185, 91);
            this.btnExit.TabIndex = 9;
            this.btnExit.Text = "Log Out";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnUpdAdmin);
            this.panel1.Controls.Add(this.btnUpdUser);
            this.panel1.Location = new System.Drawing.Point(1500, 278);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(256, 267);
            this.panel1.TabIndex = 11;
            this.panel1.Visible = false;
            // 
            // btnUpdAdmin
            // 
            this.btnUpdAdmin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUpdAdmin.Location = new System.Drawing.Point(14, 19);
            this.btnUpdAdmin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnUpdAdmin.Name = "btnUpdAdmin";
            this.btnUpdAdmin.Size = new System.Drawing.Size(226, 108);
            this.btnUpdAdmin.TabIndex = 12;
            this.btnUpdAdmin.Text = "Update Admin Profile";
            this.btnUpdAdmin.UseVisualStyleBackColor = true;
            // 
            // btnUpdUser
            // 
            this.btnUpdUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUpdUser.Location = new System.Drawing.Point(14, 144);
            this.btnUpdUser.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnUpdUser.Name = "btnUpdUser";
            this.btnUpdUser.Size = new System.Drawing.Size(226, 108);
            this.btnUpdUser.TabIndex = 0;
            this.btnUpdUser.Text = "Update User Profile";
            this.btnUpdUser.UseVisualStyleBackColor = true;
            this.btnUpdUser.Click += new System.EventHandler(this.btnUpdUser_Click);
            // 
            // button8
            // 
            this.button8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button8.Location = new System.Drawing.Point(139, 581);
            this.button8.Margin = new System.Windows.Forms.Padding(6);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(207, 76);
            this.button8.TabIndex = 12;
            this.button8.Text = "Light/Dark Mode";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btnUpdateUserProfile
            // 
            this.btnUpdateUserProfile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUpdateUserProfile.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUpdateUserProfile.Location = new System.Drawing.Point(935, 330);
            this.btnUpdateUserProfile.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnUpdateUserProfile.Name = "btnUpdateUserProfile";
            this.btnUpdateUserProfile.Size = new System.Drawing.Size(180, 91);
            this.btnUpdateUserProfile.TabIndex = 14;
            this.btnUpdateUserProfile.Text = "Update User Profile";
            this.btnUpdateUserProfile.UseVisualStyleBackColor = false;
            this.btnUpdateUserProfile.Click += new System.EventHandler(this.btnUpdateUserProfile_Click);
            // 
            // btnViewUsers
            // 
            this.btnViewUsers.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnViewUsers.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnViewUsers.Location = new System.Drawing.Point(236, 437);
            this.btnViewUsers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnViewUsers.Name = "btnViewUsers";
            this.btnViewUsers.Size = new System.Drawing.Size(180, 91);
            this.btnViewUsers.TabIndex = 18;
            this.btnViewUsers.Text = "View Users";
            this.btnViewUsers.UseVisualStyleBackColor = false;
            this.btnViewUsers.Click += new System.EventHandler(this.btnViewUsers_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox8.Image = global::Assignment_Combined.Properties.Resources.people_icon_sign_symbol_design_free_png1;
            this.pictureBox8.Location = new System.Drawing.Point(109, 445);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(104, 79);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 19;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox7.Image = global::Assignment_Combined.Properties.Resources.logout_512;
            this.pictureBox7.Location = new System.Drawing.Point(861, 566);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(104, 94);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 17;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox6.Image = global::Assignment_Combined.Properties.Resources.lightdark;
            this.pictureBox6.Location = new System.Drawing.Point(56, 581);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(74, 73);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 16;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox5.Image = global::Assignment_Combined.Properties.Resources.printer;
            this.pictureBox5.Location = new System.Drawing.Point(472, 220);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(309, 294);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 15;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.Image = global::Assignment_Combined.Properties.Resources.updateprofile;
            this.pictureBox2.Location = new System.Drawing.Point(823, 330);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(104, 91);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox4.Image = global::Assignment_Combined.Properties.Resources.delete_user;
            this.pictureBox4.Location = new System.Drawing.Point(109, 330);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(104, 79);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox3.Image = global::Assignment_Combined.Properties.Resources.user_add;
            this.pictureBox3.Location = new System.Drawing.Point(824, 220);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(104, 91);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = global::Assignment_Combined.Properties.Resources.file_medical_alt;
            this.pictureBox1.Location = new System.Drawing.Point(109, 216);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(104, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // AdminPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.btnViewUsers);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.btnUpdateUserProfile);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.btnDeleteUser);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.btnAddNewUser);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnGeneReport);
            this.Controls.Add(this.lblWelcomeAdmin);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "AdminPage";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Menu";
            this.Load += new System.EventHandler(this.AdminPage_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblWelcomeAdmin;
        private System.Windows.Forms.Button btnGeneReport;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnAddNewUser;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button btnDeleteUser;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnUpdAdmin;
        private System.Windows.Forms.Button btnUpdUser;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnUpdateUserProfile;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Button btnViewUsers;
        private System.Windows.Forms.PictureBox pictureBox8;
    }
}