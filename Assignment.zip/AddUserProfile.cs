﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Data.SqlTypes;

namespace Assignment
{
    public partial class AddUserProfile : Form
    {
        string username;
        public AddUserProfile(string Username)
        {
            InitializeComponent();
            username = Username;
        }

        //This method validates whether the username already exists in the database or not
        public bool ValidateUsername(string Username)
        {
            string UsernametoCheck = null;
            string connectionString = "Data Source = LAPTOP-7KRDTJDO; Initial Catalog = IOOP Assignment; Integrated Security = True";
            string selectCommand = $"SELECT Username FROM Users WHERE Username = '{Username}'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(selectCommand, connection))
                    try
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                            while (reader.Read())
                            {
                                UsernametoCheck = reader.GetString(0);
                            }
                        if (!string.IsNullOrEmpty(UsernametoCheck))
                        {
                            connection.Close();
                            return true;
                        }
                        else
                        {
                            connection.Close();
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        connection.Close();
                        return false;
                    }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            AdminPage adminpage = new AdminPage(username);
            adminpage.Show();
            this.Close();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            //Code for validation and assigning the variables
            if (String.IsNullOrEmpty(txtUsername.Text) || String.IsNullOrEmpty(txtFullname.Text) || String.IsNullOrEmpty(txtPassword.Text) || String.IsNullOrEmpty(txtPhone.Text) || cmbRole.SelectedIndex == -1)
            {
                MessageBox.Show("Some of the fields are empty/invalid!");
            }
            else if ((rbMale.Checked == true && rbFemale.Checked == true) || (rbMale.Checked == false && rbFemale.Checked == false))
            {
                MessageBox.Show("Some of the fields are empty/invalid!");
            }
            else if (ValidateUsername(txtUsername.Text))
            {
                MessageBox.Show("That username is already taken!");
            }
            else
            {
                try
                {
                    int phonenumber = int.Parse(txtPhone.Text);
                    MessageBox.Show("User created successfully!");

                    string username = txtUsername.Text;
                    string fullname = txtFullname.Text;
                    string password = txtPassword.Text;
                    string phone = txtPhone.Text;
                    string role = cmbRole.Text;
                    string gender;
                    if (rbMale.Checked == true)
                    {
                        gender = "Male";
                    }
                    else
                    {
                        gender = "Female";
                    }

                    //Code for creating the profile in database
                    string connectionString = "Data Source = LAPTOP-7KRDTJDO\\SQLEXPRESS; Initial Catalog = IOOP Assignment; Integrated Security = True";
                    string selectCommand = $"INSERT INTO Users (FullName, Username, Password, Phone, Gender, Role) VALUES ('{fullname}', '{username}', '{password}', {phone}, '{gender}', '{role}')";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(selectCommand, connection);

                        connection.Open();
                        int affectedRows = command.ExecuteNonQuery();
                        connection.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Some of the fields are empty/invalid!");

                }
            }
        }
    }
}