﻿namespace Assignment_Combined
{
    partial class ViewUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.datagridviewUserList = new System.Windows.Forms.DataGridView();
            this.btnExitViewUsers = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewUserList)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(318, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(583, 59);
            this.label1.TabIndex = 0;
            this.label1.Text = "Here is the list of all users";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // datagridviewUserList
            // 
            this.datagridviewUserList.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datagridviewUserList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewUserList.Location = new System.Drawing.Point(134, 140);
            this.datagridviewUserList.Name = "datagridviewUserList";
            this.datagridviewUserList.RowHeadersWidth = 82;
            this.datagridviewUserList.RowTemplate.Height = 33;
            this.datagridviewUserList.Size = new System.Drawing.Size(997, 425);
            this.datagridviewUserList.TabIndex = 1;
            // 
            // btnExitViewUsers
            // 
            this.btnExitViewUsers.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnExitViewUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExitViewUsers.Location = new System.Drawing.Point(552, 585);
            this.btnExitViewUsers.Name = "btnExitViewUsers";
            this.btnExitViewUsers.Size = new System.Drawing.Size(194, 92);
            this.btnExitViewUsers.TabIndex = 2;
            this.btnExitViewUsers.Text = "Exit";
            this.btnExitViewUsers.UseVisualStyleBackColor = false;
            this.btnExitViewUsers.Click += new System.EventHandler(this.btnExitViewUsers_Click);
            // 
            // ViewUsers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.btnExitViewUsers);
            this.Controls.Add(this.datagridviewUserList);
            this.Controls.Add(this.label1);
            this.Name = "ViewUsers";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewUsers";
            this.Load += new System.EventHandler(this.ViewUsers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewUserList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView datagridviewUserList;
        private System.Windows.Forms.Button btnExitViewUsers;
    }
}