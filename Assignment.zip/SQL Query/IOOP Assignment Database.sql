CREATE TABLE Users (
	UserID int identity (1,1) PRIMARY KEY NOT NULL,
	FullName nvarchar(50),
	Username nvarchar(50),
	Password nvarchar(50),
	Phone nvarchar(50),
	Gender nvarchar(50),
	Role nvarchar(50)
);
INSERT INTO Users (FullName, Username, Password, Phone, Gender, Role)
VALUES
	('Shrinivas Hoh', 'Shri', 'TP071957', '0163352435', 'Male', 'Admin'),
	('Demetrius Koh', 'Deme', 'TP069529', '01126269633', 'Male', 'Manager'),
	('Chaw Yan Cheng', 'Chaw', 'TP078508', '01163733386', 'Male', 'Manager'),
	('SussyAmogus', 'Sus', 'TP12629', '069696969', 'Female', 'Worker'),
	('Amal Djasreel', 'Amal', 'TP072135', '0146698123', 'Male', 'Worker'),
	('Yap Jun Kit', 'Jay', 'TP071689', '0108980861', 'Male', 'Customer'),
	('Damien See', 'Damy', 'TP071741', '0189817066', 'Female', 'Customer'),
	('Tan Wai Ken', 'Ken', 'TP070991', '0198876422', 'Male', 'Customer')

CREATE TABLE Services (
	ServiceID int PRIMARY KEY NOT NULL,
	ServiceName nvarchar(50),
	Sizes nvarchar(50),
	Fees nvarchar(50),
	Discount nvarchar(50)
);

INSERT INTO Services (ServiceID, ServiceName, Sizes, Fees, Discount) VALUES
	(1, 'Printing A4� Black and White', 'A4', '0.80/Page', '10% for over 100 pages'),
	(2, 'Printing A4 - Colour', 'A4', '2.50/Page', '10% for over 100 pages'),
	(3, 'Binding - Comb Binding', NULL, '5.50/Book', NULL),
	(4, 'Binding - Thick Cover', NULL, '9.30/Book', NULL),
	(5, 'Printing - Poster (A0, A1)', 'A0, A1', '6.00/Page', '10% for over 100 pages'),
	(6, 'Printing - Poster (A2, A3)', 'A2, A3', '3.30/Page', '10% for over 100 pages')

CREATE TABLE Requests (
	RequestID int identity (1,1) PRIMARY KEY NOT NULL,
	ServiceID int FOREIGN KEY REFERENCES Services(ServiceID),
	ServiceName nvarchar(50),
	NumofRequests int,
	Price float,
	CustomerUserID int FOREIGN KEY REFERENCES Users(UserID),
	WorkerUserID int FOREIGN KEY REFERENCES Users(UserID),
	Status nvarchar(50),
	Urgent nvarchar(5),
	DateRequested date
);

CREATE VIEW YearlyReport AS
SELECT
    YEAR(DateRequested) AS Year,
    DATENAME(MONTH, DateRequested) AS Month,
    SUM(Price) AS GrandTotal
FROM Requests
GROUP BY YEAR(DateRequested), DATENAME(MONTH, DateRequested);

CREATE VIEW ServiceReport AS 
SELECT
	Services.ServiceName,
	Year(DateRequested) AS Year,
	DATENAME(MONTH, DateRequested) AS Month,
	SUM(Price) AS Income
FROM Requests, Services 
WHERE Requests.ServiceID = Services.ServiceID
GROUP BY YEAR(DateRequested) , DATENAME(MONTH, DateRequested), Services.ServiceName

CREATE VIEW CustomerReport AS
SELECT
	Users.Username,
	Services.ServiceName,
	YEAR(DateRequested) AS Year,
	DATENAME(MONTH, DateRequested) AS Month,
	SUM(Price) as TotalMoneyPaid
FROM Users, Services, Requests
WHERE Requests.ServiceID = Services.ServiceID AND Users.UserID = Requests.CustomerUserID
GROUP BY YEAR(DateRequested) , DATENAME(MONTH, DateRequested), Services.ServiceName, Users.Username