﻿namespace Manager
{
    partial class ManagerPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCheckRequestStatus = new System.Windows.Forms.Button();
            this.btnAssignJobs = new System.Windows.Forms.Button();
            this.btnUpdateProfile = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblWelcomeManager = new System.Windows.Forms.Label();
            this.btnViewWorkers = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCheckRequestStatus
            // 
            this.btnCheckRequestStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCheckRequestStatus.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCheckRequestStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckRequestStatus.Location = new System.Drawing.Point(179, 233);
            this.btnCheckRequestStatus.Margin = new System.Windows.Forms.Padding(4);
            this.btnCheckRequestStatus.Name = "btnCheckRequestStatus";
            this.btnCheckRequestStatus.Size = new System.Drawing.Size(242, 101);
            this.btnCheckRequestStatus.TabIndex = 0;
            this.btnCheckRequestStatus.Text = "View Customer Requests";
            this.btnCheckRequestStatus.UseVisualStyleBackColor = false;
            this.btnCheckRequestStatus.Click += new System.EventHandler(this.btnCheckRequestStatus_Click);
            // 
            // btnAssignJobs
            // 
            this.btnAssignJobs.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAssignJobs.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAssignJobs.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssignJobs.Location = new System.Drawing.Point(179, 389);
            this.btnAssignJobs.Margin = new System.Windows.Forms.Padding(4);
            this.btnAssignJobs.Name = "btnAssignJobs";
            this.btnAssignJobs.Size = new System.Drawing.Size(242, 101);
            this.btnAssignJobs.TabIndex = 1;
            this.btnAssignJobs.Text = "Assign Jobs";
            this.btnAssignJobs.UseVisualStyleBackColor = false;
            this.btnAssignJobs.Click += new System.EventHandler(this.btnAssignJobs_Click);
            // 
            // btnUpdateProfile
            // 
            this.btnUpdateProfile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUpdateProfile.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUpdateProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateProfile.Location = new System.Drawing.Point(823, 389);
            this.btnUpdateProfile.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdateProfile.Name = "btnUpdateProfile";
            this.btnUpdateProfile.Size = new System.Drawing.Size(242, 101);
            this.btnUpdateProfile.TabIndex = 2;
            this.btnUpdateProfile.Text = "Update Profile";
            this.btnUpdateProfile.UseVisualStyleBackColor = false;
            this.btnUpdateProfile.Click += new System.EventHandler(this.btnUpdateProfile_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(978, 544);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(179, 98);
            this.btnLogout.TabIndex = 3;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // lblWelcomeManager
            // 
            this.lblWelcomeManager.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblWelcomeManager.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcomeManager.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lblWelcomeManager.Location = new System.Drawing.Point(392, 54);
            this.lblWelcomeManager.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWelcomeManager.Name = "lblWelcomeManager";
            this.lblWelcomeManager.Size = new System.Drawing.Size(484, 115);
            this.lblWelcomeManager.TabIndex = 4;
            this.lblWelcomeManager.Text = "Welcome, User! \r\nWhat would you like to do?";
            this.lblWelcomeManager.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnViewWorkers
            // 
            this.btnViewWorkers.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnViewWorkers.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnViewWorkers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewWorkers.Location = new System.Drawing.Point(823, 227);
            this.btnViewWorkers.Margin = new System.Windows.Forms.Padding(4);
            this.btnViewWorkers.Name = "btnViewWorkers";
            this.btnViewWorkers.Size = new System.Drawing.Size(242, 107);
            this.btnViewWorkers.TabIndex = 10;
            this.btnViewWorkers.Text = "View Workers";
            this.btnViewWorkers.UseVisualStyleBackColor = false;
            this.btnViewWorkers.Click += new System.EventHandler(this.btnViewWorkers_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox4.Image = global::Assignment_Combined.Properties.Resources.workers_worker_hat_hard_construction_1024;
            this.pictureBox4.Location = new System.Drawing.Point(1087, 227);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(120, 102);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox5.Image = global::Assignment_Combined.Properties.Resources.images;
            this.pictureBox5.Location = new System.Drawing.Point(1087, 388);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(120, 102);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 9;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox3.Image = global::Assignment_Combined.Properties.Resources.image_removebg_preview__8_;
            this.pictureBox3.Location = new System.Drawing.Point(32, 389);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(120, 102);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.Image = global::Assignment_Combined.Properties.Resources.image_removebg_preview__7_;
            this.pictureBox2.Location = new System.Drawing.Point(32, 232);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(120, 102);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = global::Assignment_Combined.Properties.Resources.download__1_;
            this.pictureBox1.Location = new System.Drawing.Point(463, 222);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(326, 282);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // ManagerPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 689);
            this.ControlBox = false;
            this.Controls.Add(this.btnCheckRequestStatus);
            this.Controls.Add(this.btnAssignJobs);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.btnViewWorkers);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblWelcomeManager);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnUpdateProfile);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ManagerPage";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ManagerPage";
            this.Load += new System.EventHandler(this.Form7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCheckRequestStatus;
        private System.Windows.Forms.Button btnAssignJobs;
        private System.Windows.Forms.Button btnUpdateProfile;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label lblWelcomeManager;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button btnViewWorkers;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}

